"""Guard clauses / safety net.

Two uses:
  1. Local: decide whether an incoming study is a primary image or a screenshot
     (SecondaryCapture) that should be skipped/flagged.
  2. Platform-side defence in depth: `verify_anonymised()` rejects any study that
     still carries identifier tags or UIDs that were not remapped by our anonymiser.
     This is a guard clause on ingest - it does NOT change how the platform analyses
     data, it only refuses PHI.

No network use.
"""
from __future__ import annotations

from pydicom.dataset import Dataset
from pydicom.uid import SecondaryCaptureImageStorage

try:
    from anonymise import ANON_UID_ROOT
except Exception:                       # allow import from either location
    from deploy.anonymise import ANON_UID_ROOT   # type: ignore

# Tags that must NOT be present in an anonymised study.
_FORBIDDEN = [
    "PatientBirthDate", "PatientAddress", "OtherPatientIDs", "OtherPatientNames",
    "ReferringPhysicianName", "PerformingPhysicianName", "NameOfPhysiciansReadingStudy",
    "OperatorsName", "InstitutionName", "InstitutionAddress",
    "InstitutionalDepartmentName", "StationName", "DeviceSerialNumber",
    "ImageComments", "PatientComments", "AdditionalPatientHistory",
]
_ID_UID_KEYWORDS = ["StudyInstanceUID", "SeriesInstanceUID", "SOPInstanceUID",
                    "FrameOfReferenceUID"]


def is_secondary_capture(ds: Dataset) -> bool:
    if str(getattr(ds, "SOPClassUID", "")) == SecondaryCaptureImageStorage:
        return True
    if str(getattr(ds, "Modality", "")).upper() in ("OT", "SC", "DOC"):
        return True
    itype = [str(x).upper() for x in ds.get("ImageType", [])]
    if "SECONDARY" in itype or "DERIVED" in itype and "PRIMARY" not in itype:
        return True
    if "ConversionType" in ds:
        return True
    return False


def _has_person_name(ds: Dataset) -> bool:
    for elem in ds:
        if elem.VR == "SQ":
            if any(_has_person_name(it) for it in elem.value):
                return True
        elif elem.VR == "PN" and elem.keyword != "PatientName":
            if str(elem.value):
                return True
    return False


def verify_anonymised(ds: Dataset) -> tuple[bool, list[str]]:
    """Return (ok, problems). ok=False means REJECT/QUARANTINE the upload."""
    problems: list[str] = []

    for kw in _FORBIDDEN:
        if kw in ds and str(ds[kw].value):
            problems.append(f"identifier present: {kw}")

    pn = str(getattr(ds, "PatientName", ""))
    if pn and pn.upper() not in ("ANONYMOUS", "ANON", "ANON^ANON"):
        problems.append(f"PatientName not anonymised: {pn!r}")
    if _has_person_name(ds):
        problems.append("a person-name (VR PN) value is present")

    for kw in _ID_UID_KEYWORDS:
        val = str(getattr(ds, kw, ""))
        if val and not val.startswith(ANON_UID_ROOT):
            problems.append(f"{kw} not remapped (missing anon root): {val}")

    if getattr(ds, "PatientIdentityRemoved", "") != "YES":
        problems.append("PatientIdentityRemoved != YES")

    return (len(problems) == 0, problems)
