Quick Rad AI - On-Prem DICOM ANONYMISER  (KAUVERY_HOSPITAL)
===========================================================

WHAT THIS IS
  A LOCAL-ONLY anonymiser. It receives DICOM studies from the scanner on the
  hospital LAN, removes patient identifiers ON THIS PC, and writes the anonymised
  study to an output folder. A technician then uploads that folder to the Quick Rad
  AI platform. This software makes NO outbound network connection - nothing leaves
  this PC automatically, and no PHI is transmitted anywhere.

WHAT IS REMOVED / KEPT (DICOM PS3.15 Basic Confidentiality Profile)
  Removed : patient name, MRN, date of birth, address, other IDs, patient comments;
            referring/performing physician, operator, institution, station name,
            device serial; free-text comments.
  Kept    : AGE and SEX; accession number (the technician's link to the patient);
            ALL clinical/technical tags - modality, series/protocol, TR, TE, IR,
            FOV, kV, mAs, image number, geometry, dates and times; vendor diffusion
            b-value private tags (Siemens 0019,100C; GE 0043,1039; Philips 2001,1003).
  UIDs    : every Study/Series/SOP/FrameOfReference UID (and referenced UIDs) is
            replaced with a fresh UID. Original UIDs never appear in the output.
  Screenshots (SecondaryCapture) are skipped, not uploaded.

INSTALL (on the hospital PC)
  1. Install Python 3.12 from https://www.python.org/downloads/  (tick "Add to PATH").
  2. Unzip this folder somewhere permanent, e.g. C:\QR_Anonymiser
  3. (Optional) Test: double-click run.bat, watch the log. Ctrl+C to stop.
  4. RIGHT-CLICK install.bat -> Run as administrator.
  5. On the scanner/PACS add a DICOM destination:
        Called AE : QR_ANONYMISER
        IP / Host : <this PC's LAN IP>   (run: ipconfig)
        Port      : 11120
     DICOM Echo should succeed; send one study.

WHERE THE OUTPUT GOES
  qr_data\output\<new_study_uid>\        anonymised .dcm files + manifest.txt
  manifest.txt lists: new-UID, accession, age, sex, series, timestamp (no PHI).
  qr_data\staging\   temporary; originals are deleted right after anonymisation.
  qr_data\anonymiser.log   activity log.

  Put qr_data\ on an encrypted volume (e.g. BitLocker) so the brief staging copy
  is encrypted at rest.

MANUAL UPLOAD
  A technician opens qr_data\output\, confirms the case via the accession number in
  manifest.txt, and uploads the folder to the Quick Rad AI platform.

REMOVE COMPLETELY
  schtasks /delete /tn "QuickRadAnonymiser" /f
  netsh advfirewall firewall delete rule name="QR Anonymiser DICOM"

NOTE ON DE-ID LIBRARY
  Anonymisation implements the DICOM PS3.15 Basic Application Level Confidentiality
  Profile directly on pydicom (no cloud, dependency-light). The two failure-prone
  areas - consistent UID remapping incl. referenced UIDs, and the private-tag
  whitelist - are covered by the verification pack (see the deployment guide).
