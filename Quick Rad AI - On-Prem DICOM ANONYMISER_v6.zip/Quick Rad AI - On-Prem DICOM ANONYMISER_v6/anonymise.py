"""Local DICOM anonymiser for the Quick Rad AI on-prem anonymiser.

Implements the DICOM PS3.15 Basic Application Level Confidentiality Profile
(identifier remove/blank), plus two things that are the usual silent failures and
so are handled explicitly and tested:

  * UID remap   - every instance-level UID (Study/Series/SOP/FrameOfReference and
                  ANY referenced-UID inside sequences) is replaced consistently with
                  a freshly generated UID under the GenZ anonymiser root. Original
                  UIDs never survive, in tags OR filenames.
  * Private-tag whitelist - all private tags are removed EXCEPT an explicit vendor
                  diffusion (b-value) whitelist, so DWI science is preserved.

No network use. This module never opens a socket.
"""
from __future__ import annotations

import datetime
from pydicom.dataset import Dataset
from pydicom.datadict import tag_for_keyword
from pydicom.uid import UID, generate_uid

# GenZ anonymiser UID root - deliberately DISTINCT from scanner/pydicom roots so the
# platform-side guard can tell a remapped study from a still-original one.
ANON_UID_ROOT = "1.2.826.0.1.3680043.10.1001."

# Default vendor diffusion b-value private tags (group, element). Configurable.
DEFAULT_PRIVATE_WHITELIST = {
    (0x0019, 0x100C),   # Siemens  b-value
    (0x0019, 0x100E),   # Siemens  B_matrix (kept with b-value)
    (0x0043, 0x1039),   # GE       b-value
    (0x2001, 0x1003),   # Philips  DiffusionBValue
}

# UID element keywords we KEEP (structural, not patient identifiers).
_KEEP_UID = {"TransferSyntaxUID", "ImplementationClassUID"}

# Identifiers to REMOVE outright (PS3.15 action X / C on free text).
_REMOVE = {
    "PatientBirthDate", "PatientBirthTime", "PatientAddress",
    "PatientTelephoneNumbers", "PatientTelecomInformation", "OtherPatientIDs",
    "OtherPatientIDsSequence", "OtherPatientNames", "PatientMotherBirthName",
    "CountryOfResidence", "RegionOfResidence", "IssuerOfPatientID",
    "ReferringPhysicianName", "ReferringPhysicianAddress",
    "ReferringPhysicianTelephoneNumbers", "ReferringPhysicianIdentificationSequence",
    "PerformingPhysicianName", "PerformingPhysicianIdentificationSequence",
    "NameOfPhysiciansReadingStudy", "PhysiciansOfRecord", "RequestingPhysician",
    "OperatorsName", "OperatorIdentificationSequence",
    "InstitutionName", "InstitutionAddress", "InstitutionalDepartmentName",
    "InstitutionCodeSequence", "StationName", "DeviceSerialNumber",
    "ImageComments", "StudyComments", "SeriesComments", "PatientComments",
    "AdditionalPatientHistory", "MedicalRecordLocator", "MilitaryRank",
    "BranchOfService", "PatientReligiousPreference", "EthnicGroup", "Occupation",
    "ResponsiblePerson", "ResponsibleOrganization",
    "RequestAttributesSequence", "ScheduledStepAttributesSequence",
    "PerformedProcedureStepDescription", "PerformedProcedureStepID",
}
# Identifiers to BLANK (kept present but non-identifying).
_BLANK = {"StudyID"}


def _keep_uid(keyword: str) -> bool:
    return keyword.endswith("ClassUID") or keyword in _KEEP_UID


class UIDMapper:
    """Consistent original->anon UID mapping for one study (shared across instances)."""

    def __init__(self) -> None:
        self._map: dict[str, str] = {}

    def remap(self, uid) -> str:
        key = str(uid)
        if key not in self._map:
            self._map[key] = generate_uid(prefix=ANON_UID_ROOT)
        return self._map[key]

    @property
    def originals(self) -> set[str]:
        return set(self._map.keys())


def _walk_remap_uids(ds: Dataset, mapper: UIDMapper) -> None:
    for elem in ds:
        if elem.VR == "SQ":
            for item in elem.value:
                _walk_remap_uids(item, mapper)
        elif elem.VR == "UI":
            if _keep_uid(elem.keyword or ""):
                continue
            if elem.VM and elem.VM > 1:
                elem.value = [mapper.remap(v) for v in elem.value]
            else:
                elem.value = mapper.remap(elem.value)


def _scrub_person_names(ds: Dataset) -> None:
    """Backstop: no person-name (VR PN) value survives except a blanked PatientName."""
    for elem in list(ds):
        if elem.VR == "SQ":
            for item in elem.value:
                _scrub_person_names(item)
        elif elem.VR == "PN":
            if elem.keyword == "PatientName":
                elem.value = "ANONYMOUS"
            else:
                del ds[elem.tag]


def _scrub_private(ds: Dataset, whitelist: set[tuple[int, int]]) -> None:
    for elem in ds:
        if elem.VR == "SQ":
            for item in elem.value:
                _scrub_private(item, whitelist)

    survivor_groups = {t.group for t in
                       (e.tag for e in ds if e.tag.is_private)
                       if (t.group, t.element) in whitelist}

    for elem in list(ds):
        t = elem.tag
        if not t.is_private:
            continue
        g, e = t.group, t.element
        if (g, e) in whitelist:
            continue                                   # keep whitelisted b-value
        if 0x10 <= e <= 0xFF and g in survivor_groups:
            continue                                   # keep creator of surviving group
        del ds[t]


def _derive_age(ds: Dataset) -> None:
    if ds.get("PatientAge"):
        return
    dob, sdate = ds.get("PatientBirthDate"), ds.get("StudyDate")
    if dob and sdate and len(dob) == 8 and len(sdate) == 8:
        try:
            b = datetime.date(int(dob[:4]), int(dob[4:6]), int(dob[6:8]))
            s = datetime.date(int(sdate[:4]), int(sdate[4:6]), int(sdate[6:8]))
            yrs = s.year - b.year - ((s.month, s.day) < (b.month, b.day))
            ds.PatientAge = f"{yrs:03d}Y"
        except Exception:
            pass


def anonymise_dataset(ds: Dataset, mapper: UIDMapper,
                      whitelist: set[tuple[int, int]] | None = None) -> Dataset:
    wl = whitelist if whitelist is not None else DEFAULT_PRIVATE_WHITELIST

    _derive_age(ds)                          # keep age before DOB is removed
    _walk_remap_uids(ds, mapper)             # I2: remap every instance UID + references

    for kw in _REMOVE:
        tag = tag_for_keyword(kw)
        if tag is not None and tag in ds:
            del ds[tag]
    for kw in _BLANK:
        tag = tag_for_keyword(kw)
        if tag is not None and tag in ds:
            ds[tag].value = ""
    _scrub_person_names(ds)                  # backstop for names
    ds.PatientID = "ANON"                    # drop the MRN, keep a valid non-id value

    _scrub_private(ds, wl)                    # I3: keep only whitelisted b-value tags

    # keep file meta instance UID in sync with the remapped SOPInstanceUID
    if getattr(ds, "file_meta", None) is not None and "SOPInstanceUID" in ds:
        ds.file_meta.MediaStorageSOPInstanceUID = ds.SOPInstanceUID

    ds.PatientIdentityRemoved = "YES"
    ds.DeidentificationMethod = "GenZ PS3.15 Basic Profile + consistent UID remap"
    return ds


def anonymise_study(datasets: list[Dataset],
                    whitelist: set[tuple[int, int]] | None = None):
    """Anonymise all instances of ONE study with a single shared UID map, so
    Study/Series/FrameOfReference and referenced UIDs remap consistently."""
    mapper = UIDMapper()
    out = []
    for ds in datasets:
        anonymise_dataset(ds, mapper, whitelist)
        out.append(ds)
    return out, mapper
