"""Quick Rad AI - on-prem DICOM ANONYMISER (local-only, no egress).

This process:
  1. Receives DICOM studies from the local scanner/PACS (inbound C-STORE, TCP 11120).
  2. Writes them to a temporary staging folder (put staging on an encrypted volume).
  3. Anonymises each completed study (DICOM PS3.15 Basic Profile + consistent UID
     remap + vendor b-value whitelist -- see anonymise.py).
  4. Writes the anonymised study to output/<new_study_uid>/ with a manifest.txt.
  5. Purges the staging original.

It NEVER makes an outbound network connection: there is no cloud endpoint and no
outbound DICOM transmission anywhere in this code. It only LISTENS for the scanner.
A technician manually uploads the contents of output/ to the Quick Rad AI platform.

Config: anonymiser_config.json (next to this file).
Run (test): python qr_anonymiser.py --console
"""
from __future__ import annotations

import io
import os
import sys
import json
import time
import shutil
import logging
import datetime
import threading

from pynetdicom import (AE, evt, AllStoragePresentationContexts,
                        ALL_TRANSFER_SYNTAXES)
from pynetdicom.sop_class import Verification
import pydicom
from pydicom.filewriter import write_file_meta_info

from anonymise import anonymise_study
from guard import is_secondary_capture


def base_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


HERE = base_dir()
_UID_TAGS = [0x0020000D, 0x00080018]   # StudyInstanceUID, SOPInstanceUID


def load_config() -> dict:
    with open(os.path.join(HERE, "anonymiser_config.json"), encoding="utf-8") as f:
        return json.load(f)


def _parse_whitelist(items) -> set[tuple[int, int]]:
    out = set()
    for s in items or []:
        g, e = s.split(",")
        out.add((int(g, 16), int(e, 16)))
    return out


class Anonymiser:
    def __init__(self) -> None:
        self.cfg = load_config()
        self.data = os.path.abspath(os.path.join(HERE, self.cfg.get("data_dir", "qr_data")))
        self.staging = os.path.join(self.data, self.cfg.get("staging_subdir", "staging"))
        self.output = os.path.join(self.data, self.cfg.get("output_subdir", "output"))
        self.flagged = os.path.join(self.data, "flagged")
        for d in (self.staging, self.output, self.flagged):
            os.makedirs(d, exist_ok=True)

        self.whitelist = _parse_whitelist(self.cfg.get("private_tag_whitelist"))
        self.reject_sc = bool(self.cfg.get("reject_secondary_capture", True))
        self.keep_staging_min = float(self.cfg.get("keep_staging_minutes", 0))

        self.log = self._logging()
        self._last_seen: dict[str, float] = {}
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._server = None

    def _logging(self) -> logging.Logger:
        handlers: list[logging.Handler] = [
            logging.FileHandler(os.path.join(self.data, "anonymiser.log"), encoding="utf-8")]
        if sys.stdout is not None:
            handlers.append(logging.StreamHandler(sys.stdout))
        logging.basicConfig(level=logging.INFO,
                            format="%(asctime)s %(levelname)s %(message)s", handlers=handlers)
        return logging.getLogger("qr-anonymiser")

    # -- Receive (SCP) -> staging (raw, no decode) -------------------------------
    def _handle_store(self, event):
        fm = event.file_meta
        raw = event.request.DataSet.getvalue()
        buf = io.BytesIO()
        buf.write(b"\x00" * 128)
        buf.write(b"DICM")
        write_file_meta_info(buf, fm)
        buf.write(raw)
        blob = buf.getvalue()

        try:
            hdr = pydicom.dcmread(io.BytesIO(blob), stop_before_pixels=True,
                                  specific_tags=_UID_TAGS)
            study_uid = str(getattr(hdr, "StudyInstanceUID", "") or "unknown")
            sop = str(getattr(hdr, "SOPInstanceUID", "") or "")
        except Exception:
            study_uid, sop = "unknown", ""
        if not sop:
            sop = str(getattr(event.request, "AffectedSOPInstanceUID", None) or time.time_ns())

        sdir = os.path.join(self.staging, study_uid)
        os.makedirs(sdir, exist_ok=True)
        try:
            with open(os.path.join(sdir, sop + ".dcm"), "wb") as f:
                f.write(blob)
        except Exception as e:  # noqa: BLE001
            self.log.error("staging write failed for %s: %s", sop, e)
            return 0xA700
        with self._lock:
            self._last_seen[study_uid] = time.time()
        return 0x0000

    # -- Anonymise one staged study -> output ------------------------------------
    def _process_study(self, staging_study: str) -> bool:
        sdir = os.path.join(self.staging, staging_study)
        files = [os.path.join(sdir, f) for f in os.listdir(sdir) if f.lower().endswith(".dcm")]
        if not files:
            return True

        primary, skipped = [], 0
        for f in files:
            try:
                ds = pydicom.dcmread(f)
            except Exception as e:  # noqa: BLE001
                self.log.warning("unreadable staged file skipped: %s (%s)", f, e)
                continue
            if self.reject_sc and is_secondary_capture(ds):
                skipped += 1
                self._flag(ds, "secondary_capture")
                continue
            primary.append(ds)

        if not primary:
            self.log.warning("study %s had no primary images (%d screenshots skipped)",
                             staging_study, skipped)
            return True

        anon, _mapper = anonymise_study(primary, self.whitelist)
        new_study = str(anon[0].StudyInstanceUID)         # remapped
        odir = os.path.join(self.output, new_study)
        os.makedirs(odir, exist_ok=True)
        for ds in anon:
            ds.save_as(os.path.join(odir, str(ds.SOPInstanceUID) + ".dcm"),
                       enforce_file_format=True)
        self._write_manifest(odir, anon, skipped)
        self.log.info("anonymised study -> output/%s (%d images, %d screenshots skipped)",
                      new_study, len(anon), skipped)
        return True

    def _write_manifest(self, odir: str, anon: list, skipped: int) -> None:
        series: dict[str, int] = {}
        for ds in anon:
            key = str(ds.get("SeriesDescription", "series"))
            series[key] = series.get(key, 0) + 1
        first = anon[0]
        lines = [
            "Quick Rad AI - anonymised case (no PHI in this file except accession)",
            f"new_study_uid : {first.StudyInstanceUID}",
            f"accession     : {first.get('AccessionNumber', '')}",
            f"age           : {first.get('PatientAge', '')}",
            f"sex           : {first.get('PatientSex', '')}",
            f"study_date    : {first.get('StudyDate', '')}",
            f"modality      : {first.get('Modality', '')}",
            "series        : " + ", ".join(f"{k} ({v})" for k, v in series.items()),
            f"images        : {len(anon)}",
            f"screenshots_skipped : {skipped}",
            f"anonymised_utc: {datetime.datetime.utcnow().isoformat(timespec='seconds')}Z",
        ]
        with open(os.path.join(odir, "manifest.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

    def _flag(self, ds, reason: str) -> None:
        try:
            fdir = os.path.join(self.flagged, reason)
            os.makedirs(fdir, exist_ok=True)
            with open(os.path.join(fdir, "log.txt"), "a", encoding="utf-8") as f:
                f.write(f"{datetime.datetime.utcnow().isoformat()} skipped "
                        f"{ds.get('SeriesDescription', '?')} ({reason})\n")
        except Exception:
            pass

    def _purge_staging(self, staging_study: str) -> None:
        if self.keep_staging_min <= 0:
            shutil.rmtree(os.path.join(self.staging, staging_study), ignore_errors=True)

    def _process_loop(self) -> None:
        quiet = int(self.cfg.get("quiet_seconds", 15))
        tick = int(self.cfg.get("tick_seconds", 10))
        while not self._stop.is_set():
            try:
                now = time.time()
                with self._lock:
                    seen = dict(self._last_seen)
                for study in list(os.listdir(self.staging)):
                    sdir = os.path.join(self.staging, study)
                    if not os.path.isdir(sdir):
                        continue
                    last = seen.get(study) or os.path.getmtime(sdir)
                    if now - last <= quiet:
                        continue
                    if self._process_study(study):
                        self._purge_staging(study)
                        with self._lock:
                            self._last_seen.pop(study, None)
            except Exception as e:  # noqa: BLE001
                self.log.error("process loop error: %s", e)
            self._stop.wait(tick)

    # -- lifecycle ---------------------------------------------------------------
    def start(self) -> None:
        self.log.info("Quick Rad AI ANONYMISER (local-only, no egress) | listen %s:%s (AE %s)",
                      self.cfg.get("bind", "0.0.0.0"), self.cfg["local_port"],
                      self.cfg.get("local_ae_title", "QR_ANONYMISER"))
        threading.Thread(target=self._process_loop, daemon=True).start()

        ae = AE(ae_title=self.cfg.get("local_ae_title", "QR_ANONYMISER"))
        ae.maximum_pdu_size = 0
        ae.acse_timeout = 120
        ae.dimse_timeout = 120
        ae.network_timeout = 600
        for cx in AllStoragePresentationContexts:
            ae.add_supported_context(cx.abstract_syntax, ALL_TRANSFER_SYNTAXES)
        ae.add_supported_context(Verification, ALL_TRANSFER_SYNTAXES)
        # start_server only LISTENS (inbound); it never dials out.
        self._server = ae.start_server(
            (self.cfg.get("bind", "0.0.0.0"), int(self.cfg["local_port"])),
            evt_handlers=[(evt.EVT_C_STORE, self._handle_store)], block=False)

    def stop(self) -> None:
        self._stop.set()
        if self._server is not None:
            try:
                self._server.shutdown()
            except Exception:
                pass
            self._server = None

    def run_console(self) -> None:
        self.start()
        try:
            while not self._stop.is_set():
                time.sleep(1)
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()


def main() -> None:
    Anonymiser().run_console()


if __name__ == "__main__":
    main()
