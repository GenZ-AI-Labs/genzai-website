@echo off
REM ============================================================================
REM  Quick Rad AI ANONYMISER - STOP + CLEAN     RUN AS ADMINISTRATOR
REM  Stops the anonymiser and clears any old/rogue copy. Safe to run repeatedly.
REM  Does NOT touch qr_data\ (your studies and logs are kept).
REM ============================================================================
setlocal EnableExtensions
cd /d "%~dp0"
set TASK=QuickRadAnonymiser
set PORT=11120

echo(
echo [1/4] Stopping and removing scheduled task...
schtasks /end    /tn "%TASK%" >nul 2>&1
schtasks /delete /tn "%TASK%" /f >nul 2>&1
echo       done.

echo [2/4] Killing any qr_anonymiser.py process (any folder)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'qr_anonymiser\.py' }; if ($p) { $p | ForEach-Object { Write-Host ('      killing PID ' + $_.ProcessId); Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } } else { Write-Host '      none found.' }"

echo [3/4] Freeing TCP port %PORT%...
set FOUND=
for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":%PORT% .*LISTENING"') do (
  echo       port held by PID %%P - killing
  taskkill /F /PID %%P >nul 2>&1
  set FOUND=1
)
if not defined FOUND echo       port %PORT% already free.

echo [4/4] Verifying clean state...
schtasks /query /tn "%TASK%" >nul 2>&1 && (echo       WARNING: task still present) || (echo       task: none.)
netstat -ano | findstr /R /C:":%PORT% .*LISTENING" >nul && (echo       WARNING: port still in use) || (echo       port %PORT%: free.)

echo(
echo Stopped and cleaned. You can run install.bat again for a fresh setup.
echo(
pause
