Quick Rad AI - On-Prem DICOM Anonymiser
=======================================

WHAT IT DOES
  Receives DICOM studies from your scanner/PACS on this PC, removes patient
  identifiers here, and writes each anonymised study to a folder for a
  technician to upload. Nothing leaves this PC automatically.

BEFORE YOU START
  Install Python 3.12 from python.org (tick "Add python.exe to PATH").
  For start-without-login, choose "Install for all users".

INSTALL  (do this once)
  1. Copy this folder to a permanent place, e.g.  C:\QR_Anonymiser
     (put it on a BitLocker/encrypted drive if possible).
  2. Right-click  install.bat  ->  Run as administrator.
  3. On the scanner/PACS add a DICOM destination:
        Called AE : QR_ANONYMISER
        IP / Host : this PC's LAN IP   (run: ipconfig)
        Port      : 11120
     Do a DICOM Echo (should succeed), then send one study.

THREE BUTTONS YOU USE
  install.bat        Set it up / re-install       (Run as administrator)
  status.bat         Check it is healthy          (safe, changes nothing)
  stop_service.bat   Stop and clean up completely (Run as administrator)

WHERE THINGS GO
  qr_data\output\           Anonymised studies + manifest.txt  (upload these)
  qr_data\flagged\failed\   Any study that could not be processed (rare)
  qr_data\anonymiser.log    Activity log (rotates automatically)

IT KEEPS RUNNING 24/7
  Starts automatically after a reboot, restarts itself if it ever stops or
  hangs, pauses safely if the disk gets low, and will not create empty folders
  or loop. Bad or screenshot images are skipped, not retried forever.

RESTRICT WHO CAN SEND  (optional but recommended)
  Out of the box it accepts studies from ANY device that can reach port 11120.
  To accept ONLY your gateway and reject every other source, do this:
    1. Send one test study from your gateway.
    2. Open  qr_data\anonymiser.log  and find the line:
         association accepted from calling AE 'XXXX' @ 10.0.0.5
       Note the AE title (XXXX) and the IP (10.0.0.5) - these are YOUR gateway's
       real values.
    3. Open  anonymiser_config.json  and set either or both:
         "allowed_calling_aet": ["XXXX"],
         "allowed_source_ip":   ["10.0.0.5"],
       (source IP is the strongest lock; AE titles can be set to anything.)
    4. Right-click install.bat -> Run as administrator (to restart with the rule).
  Anything not on the list is refused and logged as "REJECTED association".
  Leaving both lists empty [] means "accept from anyone" (the default).

DO NOT
  Delete this folder or uninstall Python - it needs both to run.

The files ending in .py and the _system folder are the program itself.
You do not need to open or edit them.
