"""Quick Rad AI - on-prem DICOM ANONYMISER (local-only, no egress).  [HARDENED v7]

Pipeline (unchanged intent):
  1. Receive DICOM studies from the local scanner/PACS (inbound C-STORE, TCP 11120).
  2. Stage them raw (put staging on an encrypted volume).
  3. Anonymise each *quiet* study (DICOM PS3.15 Basic Profile + consistent UID
     remap + vendor b-value whitelist -- see anonymise.py, UNCHANGED).
  4. Write the anonymised study ATOMICALLY to output/<new_study_uid>/ + manifest.txt.
  5. Purge the staging original.

It NEVER makes an outbound network connection. It only LISTENS for the scanner.
A technician manually uploads the contents of output/ to the Quick Rad AI platform.

--------------------------------------------------------------------------------
WHAT CHANGED vs v6 (root-cause fixes for the "infinite loop + empty folders" bug)
--------------------------------------------------------------------------------
R1  Retry cap + quarantine. A study that fails to process is retried at most
    `max_retries` times, then moved to flagged/failed/ and never retried again.
    (v6 retried a broken study forever, every tick -> infinite loop.)
R2  Atomic output. Each study is built in qr_data/.incoming/<uid>/ and only
    os.replace()'d into output/<uid>/ after ALL files + manifest are written.
    A failure therefore leaves NOTHING in output/. (v6 called os.makedirs on a
    fresh random UID BEFORE writing, so every failed retry left a new empty
    output/<random-uid>/ folder.)
R3  Idempotency ledger. processed_ledger.json maps original StudyInstanceUID ->
    result. If the process crashes AFTER writing output but BEFORE purging
    staging, the study is recognised on restart and NOT re-anonymised into a
    second, duplicate folder.
R4  Per-instance save isolation. A single unreadable/unsaveable image is flagged
    and skipped; it no longer aborts (and re-loops) the whole study.
R5  Re-bucket by real StudyInstanceUID at process time, so studies that failed
    the fast header parse (staged under "unknown") are never merged into one
    output folder / one UID map.
R6  Rotating log (size-capped) so a 24/7 box never fills its disk with the log.
R7  Single-instance guard. If TCP 11120 is already held (an old/rogue copy is
    running) the process logs it clearly and exits non-zero instead of silently
    fighting over the port; the scheduler restart + stop_service.bat handle it.

anonymise.py and guard.py (the validated de-identification logic) are UNCHANGED.
Config: anonymiser_config.json (next to this file).
Run (test): python qr_anonymiser.py --console
"""
from __future__ import annotations

import io
import os
import sys
import json
import time
import errno
import shutil
import socket
import logging
import datetime
import threading
from logging.handlers import RotatingFileHandler

from pynetdicom import (AE, evt, AllStoragePresentationContexts,
                        ALL_TRANSFER_SYNTAXES)
from pynetdicom.sop_class import Verification
import pydicom
from pydicom.filewriter import write_file_meta_info

from anonymise import anonymise_study
from guard import is_secondary_capture


def base_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


HERE = base_dir()
_UID_TAGS = [0x0020000D, 0x00080018]   # StudyInstanceUID, SOPInstanceUID


def _utc_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")


def load_config() -> dict:
    with open(os.path.join(HERE, "anonymiser_config.json"), encoding="utf-8") as f:
        return json.load(f)


def _parse_whitelist(items) -> set[tuple[int, int]]:
    out = set()
    for s in items or []:
        g, e = s.split(",")
        out.add((int(g, 16), int(e, 16)))
    return out


class Anonymiser:
    def __init__(self) -> None:
        self.cfg = load_config()
        self.data = os.path.abspath(os.path.join(HERE, self.cfg.get("data_dir", "qr_data")))
        self.staging = os.path.join(self.data, self.cfg.get("staging_subdir", "staging"))
        self.output = os.path.join(self.data, self.cfg.get("output_subdir", "output"))
        self.flagged = os.path.join(self.data, "flagged")
        self.failed = os.path.join(self.flagged, "failed")
        self.incoming = os.path.join(self.data, ".incoming")   # atomic build area (R2)
        for d in (self.staging, self.output, self.flagged, self.failed, self.incoming):
            os.makedirs(d, exist_ok=True)

        self.whitelist = _parse_whitelist(self.cfg.get("private_tag_whitelist"))
        self.reject_sc = bool(self.cfg.get("reject_secondary_capture", True))
        self.keep_staging_min = float(self.cfg.get("keep_staging_minutes", 0))
        self.max_retries = int(self.cfg.get("max_retries", 3))            # R1
        self.min_free_mb = float(self.cfg.get("min_free_mb", 500))        # W2 disk guard
        self.watchdog_seconds = int(self.cfg.get("watchdog_seconds", 300))  # W1
        self.ledger_max = int(self.cfg.get("ledger_max_entries", 5000))   # R3 cap
        # Access control (default empty = accept from anyone, backward compatible).
        self.allowed_calling_aet = [x.strip() for x in (self.cfg.get("allowed_calling_aet") or []) if str(x).strip()]
        self.allowed_source_ip = set(str(x).strip() for x in (self.cfg.get("allowed_source_ip") or []) if str(x).strip())

        self.log = self._logging()
        self._last_seen: dict[str, float] = {}
        self._attempts: dict[str, int] = {}                              # R1
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._server = None

        self.heartbeat_path = os.path.join(self.data, ".heartbeat")      # W1
        self._heartbeat = time.time()
        self._proc_thread = None
        self._low_disk_since = 0.0

        self.ledger_path = os.path.join(self.data, "processed_ledger.json")  # R3
        self._ledger = self._load_ledger()
        self._sweep_incoming()                                            # R2 cleanup

    # -- logging (rotating) ------------------------------------------------------
    def _logging(self) -> logging.Logger:
        log = logging.getLogger("qr-anonymiser")
        if log.handlers:                       # avoid duplicate handlers on re-init
            return log
        log.setLevel(logging.INFO)
        fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
        max_mb = float(self.cfg.get("log_max_mb", 20))
        backups = int(self.cfg.get("log_backups", 5))
        fh = RotatingFileHandler(os.path.join(self.data, "anonymiser.log"),
                                 maxBytes=int(max_mb * 1024 * 1024),
                                 backupCount=backups, encoding="utf-8")  # R6
        fh.setFormatter(fmt)
        log.addHandler(fh)
        if sys.stdout is not None:
            sh = logging.StreamHandler(sys.stdout)
            sh.setFormatter(fmt)
            log.addHandler(sh)
        return log

    # -- ledger (idempotency) ----------------------------------------------------
    def _load_ledger(self) -> dict:
        try:
            with open(self.ledger_path, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def _ledger_record(self, original_study_uid: str, new_uid: str, status: str) -> None:
        with self._lock:
            self._ledger[original_study_uid] = {
                "new_study_uid": new_uid, "status": status, "utc": _utc_iso()}
            # keep the ledger bounded: staging is purged on success, so only recent
            # entries can ever be re-seen after a crash. Drop the oldest beyond cap.
            if len(self._ledger) > self.ledger_max:
                for k in list(self._ledger.keys())[:-self.ledger_max]:
                    self._ledger.pop(k, None)
            tmp = self.ledger_path + ".tmp"
            try:
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(self._ledger, f, indent=2)
                os.replace(tmp, self.ledger_path)     # atomic ledger write
            except Exception as e:                    # noqa: BLE001
                self.log.error("ledger write failed: %s", e)

    def _already_done(self, original_study_uid: str) -> bool:
        rec = self._ledger.get(original_study_uid)
        return bool(rec) and rec.get("status") == "ok"

    def _sweep_incoming(self) -> None:
        """Delete any half-built study dirs left by a crash mid-write."""
        for name in os.listdir(self.incoming):
            shutil.rmtree(os.path.join(self.incoming, name), ignore_errors=True)

    # -- Receive (SCP) -> staging (raw, no decode) -------------------------------
    def _handle_store(self, event):
        # Authoritative source-IP block: refuse to store anything from a
        # non-whitelisted IP (backs up the association-level abort).
        if self.allowed_source_ip:
            try:
                addr = event.assoc.requestor.address
            except Exception:
                addr = None
            if addr not in self.allowed_source_ip:
                self.log.warning("refused C-STORE from disallowed IP %s", addr)
                return 0xA700
        fm = event.file_meta
        raw = event.request.DataSet.getvalue()
        buf = io.BytesIO()
        buf.write(b"\x00" * 128)
        buf.write(b"DICM")
        write_file_meta_info(buf, fm)
        buf.write(raw)
        blob = buf.getvalue()

        try:
            hdr = pydicom.dcmread(io.BytesIO(blob), stop_before_pixels=True,
                                  specific_tags=_UID_TAGS)
            study_uid = str(getattr(hdr, "StudyInstanceUID", "") or "unknown")
            sop = str(getattr(hdr, "SOPInstanceUID", "") or "")
        except Exception:
            study_uid, sop = "unknown", ""
        if not sop:
            sop = str(getattr(event.request, "AffectedSOPInstanceUID", None) or time.time_ns())

        study_uid = _safe_name(study_uid)
        sdir = os.path.join(self.staging, study_uid)
        os.makedirs(sdir, exist_ok=True)
        try:
            with open(os.path.join(sdir, _safe_name(sop) + ".dcm"), "wb") as f:
                f.write(blob)
        except Exception as e:  # noqa: BLE001
            self.log.error("staging write failed for %s: %s", sop, e)
            return 0xA700
        with self._lock:
            self._last_seen[study_uid] = time.time()
        return 0x0000

    # -- Anonymise one staged study folder -> output -----------------------------
    def _process_study(self, staging_study: str) -> bool:
        """Return True when the staged folder is fully handled (safe to purge).
        Raises on unexpected errors; the loop applies the retry cap (R1)."""
        sdir = os.path.join(self.staging, staging_study)
        files = [os.path.join(sdir, f) for f in os.listdir(sdir)
                 if f.lower().endswith(".dcm")]
        if not files:
            return True

        # R5: read every file, bucket by the REAL StudyInstanceUID.
        buckets: dict[str, list] = {}
        skipped = 0
        for f in files:
            try:
                ds = pydicom.dcmread(f)
            except Exception as e:  # noqa: BLE001
                self.log.warning("unreadable staged file skipped: %s (%s)", f, e)
                continue
            if self.reject_sc and is_secondary_capture(ds):
                skipped += 1
                self._flag(ds, "secondary_capture")
                continue
            key = _safe_name(str(getattr(ds, "StudyInstanceUID", "") or "unknown"))
            buckets.setdefault(key, []).append(ds)

        if not buckets:
            self.log.warning("study %s had no primary images (%d screenshots skipped)",
                             staging_study, skipped)
            return True

        all_ok = True
        for original_uid, primary in buckets.items():
            # R3: skip if we already produced output for this study.
            if self._already_done(original_uid):
                self.log.info("study %s already in ledger -> skip (idempotent)", original_uid)
                continue
            if not self._emit_bucket(original_uid, primary, skipped):
                all_ok = False
        return all_ok

    def _emit_bucket(self, original_uid: str, primary: list, skipped: int) -> bool:
        anon, _mapper = anonymise_study(primary, self.whitelist)
        new_study = _safe_name(str(anon[0].StudyInstanceUID))

        tmp_dir = os.path.join(self.incoming, new_study)
        shutil.rmtree(tmp_dir, ignore_errors=True)
        os.makedirs(tmp_dir, exist_ok=True)
        try:
            written = 0
            for ds in anon:
                dst = os.path.join(tmp_dir, _safe_name(str(ds.SOPInstanceUID)) + ".dcm")
                try:
                    ds.save_as(dst, enforce_file_format=True)
                    written += 1
                except Exception as e:  # noqa: BLE001  (R4: isolate one bad instance)
                    self.log.error("instance save failed (skipped) sop=%s: %s",
                                   getattr(ds, "SOPInstanceUID", "?"), e)
            if written == 0:
                raise RuntimeError(f"no instances saved for study {original_uid}")
            self._write_manifest(tmp_dir, anon, skipped, written)

            final_dir = os.path.join(self.output, new_study)
            if os.path.exists(final_dir):        # extremely unlikely (fresh UID)
                shutil.rmtree(final_dir, ignore_errors=True)
            os.replace(tmp_dir, final_dir)       # R2: atomic publish
        except Exception:
            shutil.rmtree(tmp_dir, ignore_errors=True)   # leave NOTHING behind
            raise
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

        self._ledger_record(original_uid, new_study, "ok")     # R3
        self.log.info("anonymised study -> output/%s (%d images, %d screenshots skipped)",
                      new_study, written, skipped)
        return True

    def _write_manifest(self, odir: str, anon: list, skipped: int, written: int) -> None:
        series: dict[str, int] = {}
        for ds in anon:
            key = str(ds.get("SeriesDescription", "series"))
            series[key] = series.get(key, 0) + 1
        first = anon[0]
        lines = [
            "Quick Rad AI - anonymised case (no PHI in this file except accession)",
            f"new_study_uid : {first.StudyInstanceUID}",
            f"accession     : {first.get('AccessionNumber', '')}",
            f"age           : {first.get('PatientAge', '')}",
            f"sex           : {first.get('PatientSex', '')}",
            f"study_date    : {first.get('StudyDate', '')}",
            f"modality      : {first.get('Modality', '')}",
            "series        : " + ", ".join(f"{k} ({v})" for k, v in series.items()),
            f"images        : {written}",
            f"screenshots_skipped : {skipped}",
            f"anonymised_utc: {_utc_iso()}",
        ]
        with open(os.path.join(odir, "manifest.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

    def _flag(self, ds, reason: str) -> None:
        try:
            fdir = os.path.join(self.flagged, reason)
            os.makedirs(fdir, exist_ok=True)
            with open(os.path.join(fdir, "log.txt"), "a", encoding="utf-8") as f:
                f.write(f"{_utc_iso()} skipped "
                        f"{ds.get('SeriesDescription', '?')} ({reason})\n")
        except Exception:
            pass

    def _quarantine(self, staging_study: str, reason: str) -> None:
        """Move a permanently-failing study out of staging so it stops looping (R1)."""
        src = os.path.join(self.staging, staging_study)
        dst = os.path.join(self.failed, f"{staging_study}__{int(time.time())}")
        try:
            shutil.move(src, dst)
            with open(os.path.join(dst, "_why.txt"), "w", encoding="utf-8") as f:
                f.write(f"quarantined_utc: {_utc_iso()}\nreason: {reason}\n"
                        f"attempts: {self.max_retries}\n")
            self.log.error("study %s quarantined after %d attempts -> flagged/failed/",
                           staging_study, self.max_retries)
        except Exception as e:  # noqa: BLE001
            self.log.error("quarantine failed for %s: %s", staging_study, e)
            shutil.rmtree(src, ignore_errors=True)

    def _purge_staging(self, staging_study: str) -> None:
        if self.keep_staging_min <= 0:
            shutil.rmtree(os.path.join(self.staging, staging_study), ignore_errors=True)

    def _free_mb(self) -> float:
        try:
            return shutil.disk_usage(self.data).free / (1024 * 1024)
        except Exception:
            return float("inf")

    def _beat(self) -> None:
        """Update the liveness heartbeat (W1). Never raises."""
        self._heartbeat = time.time()
        try:
            with open(self.heartbeat_path, "w", encoding="utf-8") as f:
                f.write(_utc_iso())
        except Exception:
            pass

    def _process_loop(self) -> None:
        quiet = int(self.cfg.get("quiet_seconds", 15))
        tick = int(self.cfg.get("tick_seconds", 10))
        while not self._stop.is_set():
            try:
                self._beat()                                   # W1 liveness
                now = time.time()

                # W2: if the disk is low, PAUSE processing rather than fail/lose
                # studies. Nothing is quarantined; work resumes when space returns.
                free = self._free_mb()
                if free < self.min_free_mb:
                    if now - self._low_disk_since > 60:
                        self.log.error("LOW DISK: %.0f MB free (< %.0f MB). Pausing "
                                       "processing; staged studies are safe.",
                                       free, self.min_free_mb)
                        self._low_disk_since = now
                    self._stop.wait(tick)
                    continue
                self._low_disk_since = 0.0

                with self._lock:
                    seen = dict(self._last_seen)
                for study in list(os.listdir(self.staging)):
                    sdir = os.path.join(self.staging, study)
                    if not os.path.isdir(sdir):
                        continue
                    last = seen.get(study) or os.path.getmtime(sdir)
                    if now - last <= quiet:
                        continue
                    self._handle_one(study)
            except Exception as e:  # noqa: BLE001
                self.log.error("process loop error: %s", e)
            self._stop.wait(tick)

    def _handle_one(self, study: str) -> None:
        """Process one staged study with the retry cap (R1). Never raises."""
        try:
            done = self._process_study(study)
        except Exception as e:  # noqa: BLE001
            n = self._attempts.get(study, 0) + 1
            self._attempts[study] = n
            self.log.error("study %s process error (attempt %d/%d): %s",
                           study, n, self.max_retries, e)
            if n >= self.max_retries:
                self._quarantine(study, str(e))
                self._attempts.pop(study, None)
                with self._lock:
                    self._last_seen.pop(study, None)
            return

        if done:
            self._purge_staging(study)
            self._attempts.pop(study, None)
            with self._lock:
                self._last_seen.pop(study, None)

    # -- access control / visibility --------------------------------------------
    def _on_accepted(self, event):
        """Log who connected (so you can read the real AE/IP), and enforce the
        optional source-IP whitelist. Calling-AE whitelist is enforced by
        pynetdicom's require_calling_aet before this fires."""
        try:
            addr = event.assoc.requestor.address
            aet = event.assoc.requestor.ae_title
            if isinstance(aet, bytes):
                aet = aet.decode(errors="ignore")
            aet = str(aet).strip()
        except Exception:
            addr, aet = "?", "?"
        if self.allowed_source_ip and addr not in self.allowed_source_ip:
            self.log.warning("REJECTED association: source IP %s not in allowed_source_ip "
                             "(calling AE '%s')", addr, aet)
            try:
                event.assoc.abort()
            except Exception:
                pass
            return
        self.log.info("association accepted from calling AE '%s' @ %s", aet, addr)

    # -- watchdog (self-heal) ----------------------------------------------------
    def _watchdog_loop(self) -> None:
        """If the processing thread dies or wedges (no heartbeat for
        watchdog_seconds), force a non-zero exit so Task Scheduler restarts a
        clean process. This is the last line of defence for 24/7 operation (W1)."""
        poll = int(self.cfg.get("watchdog_poll_seconds",
                                max(2, min(30, self.watchdog_seconds // 2))))
        while not self._stop.wait(poll):
            try:
                stale = time.time() - self._heartbeat
                alive = self._proc_thread is not None and self._proc_thread.is_alive()
                if not alive or stale > self.watchdog_seconds:
                    self.log.critical("WATCHDOG: proc_alive=%s heartbeat_age=%.0fs "
                                      "-> forcing restart (exit 4)", alive, stale)
                    logging.shutdown()
                    os._exit(4)                      # scheduler restart-on-failure
            except Exception:
                # a watchdog must never die quietly; force restart if it somehow does
                os._exit(4)

    # -- single-instance guard ---------------------------------------------------
    def _port_in_use(self) -> bool:
        host = self.cfg.get("bind", "0.0.0.0")
        probe = host if host not in ("0.0.0.0", "") else "127.0.0.1"
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.settimeout(1.0)
            s.connect((probe, int(self.cfg["local_port"])))
            return True
        except OSError:
            return False
        finally:
            s.close()

    # -- lifecycle ---------------------------------------------------------------
    def start(self) -> None:
        if self._port_in_use():                                          # R7
            self.log.error("port %s already in use - another QR Anonymiser instance is "
                           "running. Run stop_service.bat first. Exiting.",
                           self.cfg["local_port"])
            raise SystemExit(3)

        self.log.info("Quick Rad AI ANONYMISER v7 (local-only, no egress) | listen %s:%s (AE %s)",
                      self.cfg.get("bind", "0.0.0.0"), self.cfg["local_port"],
                      self.cfg.get("local_ae_title", "QR_ANONYMISER"))
        self._beat()
        self._proc_thread = threading.Thread(target=self._process_loop, daemon=True)
        self._proc_thread.start()
        threading.Thread(target=self._watchdog_loop, daemon=True).start()   # W1

        ae = AE(ae_title=self.cfg.get("local_ae_title", "QR_ANONYMISER"))
        ae.maximum_pdu_size = 0
        ae.acse_timeout = 120
        ae.dimse_timeout = 120
        ae.network_timeout = 600
        # Access control: only restrict when a whitelist is configured (else open).
        if self.allowed_calling_aet:
            ae.require_calling_aet = self.allowed_calling_aet
            self.log.info("inbound RESTRICTED to calling AE title(s): %s", self.allowed_calling_aet)
        else:
            self.log.info("inbound: accepting ANY calling AE title (allowed_calling_aet empty)")
        if self.allowed_source_ip:
            self.log.info("inbound RESTRICTED to source IP(s): %s", sorted(self.allowed_source_ip))
        for cx in AllStoragePresentationContexts:
            ae.add_supported_context(cx.abstract_syntax, ALL_TRANSFER_SYNTAXES)
        ae.add_supported_context(Verification, ALL_TRANSFER_SYNTAXES)
        try:
            self._server = ae.start_server(
                (self.cfg.get("bind", "0.0.0.0"), int(self.cfg["local_port"])),
                evt_handlers=[(evt.EVT_C_STORE, self._handle_store),
                              (evt.EVT_ACCEPTED, self._on_accepted)], block=False)
        except OSError as e:
            if e.errno in (errno.EADDRINUSE, getattr(errno, "WSAEADDRINUSE", 10048)):
                self.log.error("bind failed (port busy) - old instance still up. Exiting.")
                raise SystemExit(3)
            raise

    def stop(self) -> None:
        self._stop.set()
        if self._server is not None:
            try:
                self._server.shutdown()
            except Exception:
                pass
            self._server = None

    def run_console(self) -> None:
        self.start()
        try:
            while not self._stop.is_set():
                time.sleep(1)
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()


def _safe_name(name: str) -> str:
    """Filesystem-safe folder/file name (defensive; UIDs are already safe)."""
    bad = '<>:"/\\|?*\0'
    out = "".join("_" if c in bad else c for c in str(name)).strip().rstrip(".")
    return out or "unknown"


def main() -> None:
    Anonymiser().run_console()


if __name__ == "__main__":
    main()
