@echo off
REM ============================================================================
REM  Quick Rad AI ANONYMISER - INSTALL          RUN AS ADMINISTRATOR
REM  Receives DICOM locally, anonymises on this PC, writes to qr_data\output\.
REM  Local-only: no outbound connection. Safe to re-run.
REM ============================================================================
setlocal EnableExtensions
cd /d "%~dp0"
set TASK=QuickRadAnonymiser
set PORT=11120

net session >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Not running as administrator.
  echo         Right-click install.bat  -^>  Run as administrator.
  pause
  exit /b 1
)

echo [0/5] Cleaning any previous copy...
schtasks /end    /tn "%TASK%" >nul 2>&1
schtasks /delete /tn "%TASK%" /f >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'qr_anonymiser\.py' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1
for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":%PORT% .*LISTENING"') do taskkill /F /PID %%P >nul 2>&1

set "PY="
for /f "delims=" %%P in ('where python 2^>nul') do if not defined PY set "PY=%%P"
set "PYW="
for /f "delims=" %%P in ('where pythonw 2^>nul') do if not defined PYW set "PYW=%%P"
if not defined PY (
  echo [ERROR] python.exe is not on PATH. Install Python 3.12 and tick "Add python.exe to PATH".
  pause
  exit /b 1
)
if not defined PYW (
  echo [ERROR] pythonw.exe is not on PATH.
  pause
  exit /b 1
)
echo       python : %PY%
echo       pythonw: %PYW%

echo [1/5] Installing packages...
set "DEPS_OK="
if exist "%~dp0_system\wheels\*.whl" (
  "%PY%" -m pip install --quiet --no-index --find-links "%~dp0_system\wheels" pydicom pynetdicom
  if not errorlevel 1 set "DEPS_OK=1"
)
if not defined DEPS_OK (
  echo       installing from internet...
  "%PY%" -m pip install --quiet pydicom==3.0.2 pynetdicom==3.0.4
  if not errorlevel 1 set "DEPS_OK=1"
)
if not defined DEPS_OK (
  echo [ERROR] package install failed.
  pause
  exit /b 1
)
"%PY%" -c "import pydicom, pynetdicom" 2>nul
if errorlevel 1 (
  echo [ERROR] package import check failed.
  pause
  exit /b 1
)
echo       packages OK.

echo [2/5] Opening inbound firewall port TCP %PORT%...
netsh advfirewall firewall delete rule name="QR Anonymiser DICOM" >nul 2>&1
netsh advfirewall firewall add rule name="QR Anonymiser DICOM" dir=in action=allow protocol=TCP localport=%PORT% >nul

echo [3/5] Building auto-start task...
set "TEMPLATE=%~dp0_system\task_system_onstart.xml"
set "MODE=boot start (SYSTEM)"
echo %PYW% | findstr /I "\\Users\\" >nul
if not errorlevel 1 (
  set "TEMPLATE=%~dp0_system\task_user_onlogon.xml"
  set "MODE=logon start (Python is a per-user install)"
)
set "WORKDIR=%~dp0"
if "%WORKDIR:~-1%"=="\" set "WORKDIR=%WORKDIR:~0,-1%"
set "PS_TEMPLATE=%TEMPLATE%"
set "PS_PYW=%PYW%"
set "PS_SCRIPT=%~dp0qr_anonymiser.py"
set "PS_WORKDIR=%WORKDIR%"
set "PS_USER=%USERDOMAIN%\%USERNAME%"
set "TASKXML=%TEMP%\qr_task_active.xml"
set "PS_OUT=%TASKXML%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$t = Get-Content -Raw -LiteralPath $env:PS_TEMPLATE; $t = $t.Replace('__PYW__',$env:PS_PYW).Replace('__SCRIPT__',$env:PS_SCRIPT).Replace('__WORKDIR__',$env:PS_WORKDIR).Replace('__USER__',$env:PS_USER); Set-Content -LiteralPath $env:PS_OUT -Value $t -Encoding Unicode"
if not exist "%TASKXML%" (
  echo [ERROR] could not build task definition.
  pause
  exit /b 1
)

echo [4/5] Registering and starting the task (%MODE%)...
schtasks /create /tn "%TASK%" /xml "%TASKXML%" /f
if errorlevel 1 (
  echo [ERROR] could not create task. Make sure you used "Run as administrator".
  del "%TASKXML%" >nul 2>&1
  pause
  exit /b 1
)
del "%TASKXML%" >nul 2>&1
schtasks /run /tn "%TASK%" >nul 2>&1
timeout /t 3 >nul

echo [5/5] Verifying...
echo ============================================================
netstat -ano | findstr /R /C:":%PORT% .*LISTENING" >nul && (echo   OK - listening on port %PORT%) || (echo   NOT listening yet - check qr_data\anonymiser.log)
echo ============================================================
echo Installed (%MODE%).
echo   Anonymised studies : %~dp0qr_data\output\
echo   Activity log       : %~dp0qr_data\anonymiser.log
echo   Check health later : status.bat        Stop / remove : stop_service.bat
echo.
pause
