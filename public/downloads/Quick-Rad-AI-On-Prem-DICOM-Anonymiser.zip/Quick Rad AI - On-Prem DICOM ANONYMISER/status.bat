@echo off
REM ============================================================================
REM  Quick Rad AI ANONYMISER - STATUS (read-only). Changes nothing.
REM ============================================================================
setlocal EnableExtensions
cd /d "%~dp0"
set TASK=QuickRadAnonymiser
set PORT=11120

echo(
echo ============================================================
echo  Quick Rad AI Anonymiser - status
echo ============================================================
echo(
echo [Scheduled task]
schtasks /query /tn "%TASK%" /v /fo LIST 2>nul | findstr /I "TaskName Status \"Last Run\" \"Last Result\" \"Next Run\""
if errorlevel 1 echo   NOT INSTALLED (run install.bat as administrator).
echo(
echo [Running process]
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'qr_anonymiser\.py' }; if ($p) { $p | ForEach-Object { Write-Host ('   PID ' + $_.ProcessId + '  running') } } else { Write-Host '   not running' }"
echo(
echo [Port %PORT% listener]
netstat -ano | findstr /R /C:":%PORT% .*LISTENING" || echo   not listening
echo(
echo [Heartbeat]
if exist "qr_data\.heartbeat" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$t=[datetime](Get-Content -Raw 'qr_data\.heartbeat'); $age=[int]((Get-Date).ToUniversalTime()-$t).TotalSeconds; Write-Host ('   last beat '+$t.ToString('u')+'  ('+$age+'s ago)'); if($age -gt 300){Write-Host '   WARNING: heartbeat stale (>300s).'}"
) else (
  echo   no heartbeat file yet.
)
echo(
echo [Output]
if exist "qr_data\output" (
  for /f %%C in ('dir /b /ad "qr_data\output" 2^>nul ^| find /c /v ""') do echo   %%C anonymised study folder(s) waiting for upload.
) else (
  echo   no output folder yet.
)
if exist "qr_data\flagged\failed" (
  for /f %%C in ('dir /b /ad "qr_data\flagged\failed" 2^>nul ^| find /c /v ""') do echo   %%C quarantined study folder(s) in flagged\failed\.
)
echo(
echo [Last 12 log lines]
if exist "qr_data\anonymiser.log" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Content 'qr_data\anonymiser.log' -Tail 12 | ForEach-Object { '   '+$_ }"
) else (
  echo   no log yet.
)
echo(
echo ============================================================
pause
