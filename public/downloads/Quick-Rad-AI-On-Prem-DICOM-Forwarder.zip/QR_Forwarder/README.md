# Quick Rad AI — On-Prem DICOM Forwarder

A small **store-and-forward gateway** that runs on a hospital PC (the one with
internet). The scanner sends studies to this PC over the local LAN; the forwarder
receives them and pushes them to the Quick Rad AI cloud — 24/7, with retry if the
internet drops. **Nothing is lost, and it never stops.**

```
Hospital LAN (no internet)           This PC (internet)                  Cloud
  Scanner ──C-STORE──►  QR_GATEWAY (port 11120) ──C-STORE──►  QUICKRAD_AI
                        forwards as "<YOUR SITE AE>"          <cloud host> : 11112
                        store-and-forward + retry + logs
```

The branch identity is set **here in the forwarder** — so the cloud routes every
study to the right branch. The scanner just sends locally.

---

## Settings for your site

Two values are issued by GenzAI Labs per site and are **not included in this
download**. Request them from your GenzAI Labs contact before you start:

| Setting | Where it goes | Who provides it |
|---|---|---|
| Branch AE title | `branch_ae_title` in `forwarder_config.json` | GenzAI Labs |
> **AE titles are capped at 16 characters by the DICOM standard.** A longer value
> is rejected before the forwarder starts, with the error
> `Invalid 'ae_title' value ... must not exceed 16 characters`.
| Cloud host | `cloud_host` in `forwarder_config.json` | GenzAI Labs |

Everything else in `forwarder_config.json` is already set correctly. The file
ships with both values as `SET_SITE_AE` / `SET_CLOUD_HOST` — the forwarder will not start until
you fill them in.

| Setting | Value |
|---|---|
| This PC listens on | **port 11120**, AE **QR_GATEWAY** |
| Cloud port / AE | 11112, AE QUICKRAD_AI |

---

## Files
| File | Purpose |
|---|---|
| `qr_forwarder.py` | the service |
| `forwarder_config.json` | per-hospital settings (branch AE, cloud host, ports) |
| `requirements.txt` | Python deps |
| `run.bat` | manual run (testing only — shows logs) |
| `install_task.bat` | install as a hidden 24/7 auto-start job |
| `uninstall_forwarder.bat` | remove the job, firewall rule and (optionally) data |

---

## Before you start (do this in the Quick Rad AI app)
Log in as super-admin → **My Profile → AE Titles** → add your branch AE title.
If this is not done first, the cloud rejects the connection and nothing arrives.

---

## One-time installation (on the hospital PC)

### 1. Install Python
- Install **Python 3.12** from https://www.python.org/downloads/
- ✅ tick **"Add python.exe to PATH"** during install.
- Check: `python --version`

### 2. Copy this folder to the PC
e.g. `C:\QR_Forwarder`

### 3. Fill in `forwarder_config.json`
Open it in Notepad and replace `SET_SITE_AE` and
`SET_CLOUD_HOST` with the values GenzAI Labs issued for this site.

### 4. Find this PC's LAN IP
```
ipconfig
```
Note the IPv4 address (e.g. 192.168.1.50). Ask the centre's IT to make it a
**static / DHCP-reserved** IP — if it changes, the scanner stops finding it.

### 5. Open the Windows Firewall (inbound)
Command Prompt **as administrator**:
```
netsh advfirewall firewall add rule name="QR Forwarder DICOM" dir=in action=allow protocol=TCP localport=11120
```

### 6. Test it once
Double-click `run.bat`. You should see a startup line naming your branch AE, the
listen port, and the cloud host. Leave it running for step 7.

### 7. Point the scanner at THIS PC
On the scanner/PACS, add a DICOM send destination:
```
Called AE : QR_GATEWAY
IP / Host : <THIS PC's LAN IP>
Port      : 11120
```
Do a **DICOM Echo** → should succeed. Then send one small study and watch the
window for `forwarded N image(s) for study ...`, and check it appears in the
Quick Rad AI worklist. Press `Ctrl+C` to stop `run.bat`.

### 8. Install as a hidden 24/7 job
**Right-click `install_task.bat` → Run as administrator.**

This creates a Windows Task Scheduler job `QuickRadForwarder` that runs hidden
(via `pythonw.exe`) and starts again at every logon.

> Use **Task Scheduler**, not NSSM/`install_service.bat`. NSSM needs the Windows
> account password, which is often unavailable on a PC administered remotely.

> ⚠️ The task starts at **logon, not boot**. After a reboot the PC must be logged
> in, or the forwarder won't start. Leave the PC logged in (or enable auto-logon).

### 9. Verify
```
schtasks /query /tn "QuickRadForwarder"
type qr_forwarder_data\forwarder.log
```
Send one more study and confirm it reaches the worklist.

---

## How it flows (once live)
```
Scanner ──► this PC (QR_GATEWAY:11120) ──► cloud (as <YOUR SITE AE>) ──► your worklist
```
- Study complete? The forwarder waits `quiet_seconds` (15s) of silence, then forwards.
- Cloud/internet down? It keeps the study and **retries every 30s** until it succeeds.
- Logs: `qr_forwarder_data\forwarder.log` · sent studies kept 3 days in `qr_forwarder_data\sent`.

## Manage the job
```
schtasks /query  /tn "QuickRadForwarder"      :: status
schtasks /run    /tn "QuickRadForwarder"      :: start now
schtasks /end    /tn "QuickRadForwarder"      :: stop
schtasks /delete /tn "QuickRadForwarder" /f   :: remove
```

## Troubleshooting
- **Nothing arrives in the cloud** → check `forwarder.log`. *"cloud rejected the
  association"* means your branch AE isn't registered in the app (My Profile → AE
  Titles), or this PC can't reach the cloud. Test outbound connectivity to the
  cloud host and port 11112 with `Test-NetConnection <cloud host> -Port 11112`.
- **Config still has `SET_SITE_AE` / `SET_CLOUD_HOST`** → step 3 was skipped.
- **Scanner can't reach the forwarder** → check this PC's LAN IP and that inbound
  TCP 11120 is allowed through Windows Firewall (step 5).
- **Nothing runs after a reboot** → nobody logged in; see the warning in step 8.

## Uninstalling
**Right-click `uninstall_forwarder.bat` → Run as administrator.** It stops the
job, deletes the scheduled task and the firewall rule, and offers to back up
`qr_forwarder_data` first.

> ⚠️ The data folder can hold **un-forwarded studies**. The script warns and asks
> you to type `DELETE` before removing it. Take the backup.

## Do not redistribute `qr_forwarder_data`
That folder holds `forwarder.log` and queued studies. The log records Study
Instance UIDs and the site's AE title, so it is **patient data plus site
configuration**. Never attach it to a public download, an email thread, or a
ticket — send it only to your GenzAI Labs contact when asked, and only for the
site it came from.

## Adding another branch
Copy this folder, change **one line** — `branch_ae_title` in
`forwarder_config.json` — register that AE in the app, run `install_task.bat`.
