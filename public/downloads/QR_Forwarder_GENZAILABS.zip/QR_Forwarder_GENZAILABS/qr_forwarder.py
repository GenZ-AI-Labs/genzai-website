"""Quick Rad AI — on-prem DICOM forwarder (store-and-forward gateway).

Runs on a hospital PC that has internet access. The scanner/PACS sends studies to
THIS PC as a local DICOM node (on the hospital LAN); this service receives them
and forwards each study to the Quick Rad AI cloud, stamping the branch's Calling
AE title so the cloud routes it to the correct branch.

Store-and-forward with retry: if the internet or cloud is temporarily down, studies
are kept on disk and retried until they go through — nothing is lost. Designed to
run 24/7 as a service (Windows Task Scheduler / Linux systemd). The service
self-restarts on any error, so it never stops.

Receive is a FAST PATH: incoming instances are written to disk as raw bytes with no
decode/re-encode, so C-STORE responses return to the scanner immediately (a real
PACS behaves this way). Decoding only happens later, in the background forward loop,
off the scanner's path — so even a 500-image MR series never makes the scanner wait
long enough to report a failure.

Config: forwarder_config.json (in this same folder).
"""
from __future__ import annotations

import io
import os
import sys
import json
import time
import shutil
import logging
import threading

from pynetdicom import (AE, evt, AllStoragePresentationContexts,
                        ALL_TRANSFER_SYNTAXES)
from pynetdicom.sop_class import Verification
import pydicom
from pydicom.filewriter import write_file_meta_info

# Folder the exe/script lives in — works both as a .py and as a PyInstaller .exe.
if getattr(sys, "frozen", False):
    HERE = os.path.dirname(sys.executable)
else:
    HERE = os.path.dirname(os.path.abspath(__file__))


def load_config() -> dict:
    with open(os.path.join(HERE, "forwarder_config.json"), encoding="utf-8") as f:
        return json.load(f)


CFG = load_config()
DATA = os.path.abspath(os.path.join(HERE, CFG.get("storage_dir", "qr_forwarder_data")))
INCOMING = os.path.join(DATA, "incoming")
SENT = os.path.join(DATA, "sent")
for _d in (INCOMING, SENT):
    os.makedirs(_d, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[
        logging.FileHandler(os.path.join(DATA, "forwarder.log"), encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger("qr-forwarder")

_last_seen: dict[str, float] = {}
_lock = threading.Lock()

# Only the two UIDs we need to file the instance — a header-only read (no pixels),
# so grouping costs almost nothing on the scanner-facing path.
_UID_TAGS = [0x0020000D, 0x00080018]   # StudyInstanceUID, SOPInstanceUID


# ── Receive (SCP): the scanner pushes studies here — FAST, no decode ────────
def _handle_store(event):
    """Write the incoming instance to disk as raw bytes (no decode / no re-encode)
    and acknowledge immediately. Building the file bytes = preamble + DICM + file
    meta + the raw dataset exactly as it arrived; pixels are copied through
    untouched. A tiny header-only parse (transfer syntax known from the file meta,
    pixels skipped) gives us the Study/SOP UIDs for filing. This is what keeps big
    MR series from stalling the scanner."""
    fm = event.file_meta
    raw = event.request.DataSet.getvalue()          # raw encoded dataset, not decoded

    buf = io.BytesIO()
    buf.write(b"\x00" * 128)
    buf.write(b"DICM")
    write_file_meta_info(buf, fm)
    buf.write(raw)
    blob = buf.getvalue()

    try:
        hdr = pydicom.dcmread(io.BytesIO(blob), stop_before_pixels=True,
                              specific_tags=_UID_TAGS)
        study_uid = str(getattr(hdr, "StudyInstanceUID", "") or "unknown")
        sop = str(getattr(hdr, "SOPInstanceUID", "") or "")
    except Exception:
        study_uid, sop = "unknown", ""
    if not sop:
        sop = str(getattr(event.request, "AffectedSOPInstanceUID", None) or time.time_ns())

    sdir = os.path.join(INCOMING, study_uid)
    os.makedirs(sdir, exist_ok=True)
    try:
        with open(os.path.join(sdir, sop + ".dcm"), "wb") as f:
            f.write(blob)
    except Exception as e:  # noqa: BLE001
        log.error("store write failed for %s: %s", sop, e)
        return 0xA700   # Out of Resources — the scanner will resend just this image
    with _lock:
        _last_seen[study_uid] = time.time()
    return 0x0000  # Success


# ── Forward (SCU): push a completed study to the cloud ──────────────────────
def _forward_study(study_uid: str) -> bool:
    sdir = os.path.join(INCOMING, study_uid)
    files = [os.path.join(sdir, f) for f in os.listdir(sdir) if f.lower().endswith(".dcm")]
    if not files:
        return True

    contexts, datasets = set(), []
    for f in files:
        try:
            ds = pydicom.dcmread(f)
            ts = ds.file_meta.TransferSyntaxUID
            contexts.add((ds.SOPClassUID, ts))
            datasets.append(ds)
        except Exception as e:  # noqa: BLE001
            log.warning("unreadable file skipped: %s (%s)", f, e)
    if not datasets:
        return True

    ae = AE(ae_title=CFG["branch_ae_title"])
    for sop_class, ts in contexts:
        ae.add_requested_context(sop_class, ts)
    try:
        assoc = ae.associate(CFG["cloud_host"], int(CFG["cloud_port"]),
                             ae_title=CFG.get("cloud_ae_title", "QUICKRAD_AI"))
    except Exception as e:  # noqa: BLE001
        log.error("associate to cloud failed: %s", e)
        return False
    if not assoc.is_established:
        log.error("cloud rejected the association (check AE title registration / firewall)")
        return False

    ok, n = True, 0
    for ds in datasets:
        try:
            st = assoc.send_c_store(ds)
            if not st or st.Status != 0x0000:
                log.error("C-STORE rejected status=0x%04X", getattr(st, "Status", -1))
                ok = False
                break
            n += 1
        except Exception as e:  # noqa: BLE001
            log.error("C-STORE send error: %s", e)
            ok = False
            break
    assoc.release()
    if ok:
        log.info("forwarded %d image(s) for study %s", n, study_uid)
    return ok


def _purge_old_sent():
    keep_days = float(CFG.get("keep_sent_days", 3))
    cutoff = time.time() - keep_days * 86400
    for name in os.listdir(SENT):
        p = os.path.join(SENT, name)
        try:
            if os.path.isdir(p) and os.path.getmtime(p) < cutoff:
                shutil.rmtree(p, ignore_errors=True)
        except Exception:
            pass


def _forward_loop():
    quiet = int(CFG.get("quiet_seconds", 15))
    retry = int(CFG.get("retry_seconds", 30))
    while True:
        try:
            now = time.time()
            with _lock:
                seen = dict(_last_seen)
            ready = []
            for study_uid in os.listdir(INCOMING):
                sdir = os.path.join(INCOMING, study_uid)
                if not os.path.isdir(sdir):
                    continue
                last = seen.get(study_uid) or os.path.getmtime(sdir)
                if now - last > quiet:          # study is complete (quiet) or leftover
                    ready.append(study_uid)
            for study_uid in ready:
                log.info("forwarding study %s as '%s' -> %s:%s",
                         study_uid, CFG["branch_ae_title"], CFG["cloud_host"], CFG["cloud_port"])
                if _forward_study(study_uid):
                    dst = os.path.join(SENT, study_uid)
                    if os.path.exists(dst):
                        shutil.rmtree(dst, ignore_errors=True)
                    try:
                        os.rename(os.path.join(INCOMING, study_uid), dst)
                    except Exception:
                        pass
                    with _lock:
                        _last_seen.pop(study_uid, None)
                else:
                    log.warning("study %s not forwarded — will retry in %ss", study_uid, retry)
            _purge_old_sent()
        except Exception as e:  # noqa: BLE001
            log.error("forward loop error: %s", e)
        time.sleep(retry)


def main():
    log.info("Quick Rad AI forwarder | branch='%s' | listen 0.0.0.0:%s (AE %s) | cloud %s:%s (AE %s)",
             CFG["branch_ae_title"], CFG["local_port"], CFG.get("local_ae_title", "QR_GATEWAY"),
             CFG["cloud_host"], CFG["cloud_port"], CFG.get("cloud_ae_title", "QUICKRAD_AI"))
    threading.Thread(target=_forward_loop, daemon=True).start()

    ae = AE(ae_title=CFG.get("local_ae_title", "QR_GATEWAY"))
    # Generous negotiation so a big MR series never trips a sender timeout, and a
    # large PDU so throughput stays high. These are safety margins; the real speed
    # win is the no-decode store handler above.
    ae.maximum_pdu_size = 0            # 0 = no limit; let the scanner use big PDUs
    ae.acse_timeout = 120
    ae.dimse_timeout = 120
    ae.network_timeout = 600
    for cx in AllStoragePresentationContexts:          # accept every storage class
        ae.add_supported_context(cx.abstract_syntax, ALL_TRANSFER_SYNTAXES)  # incl. compressed
    ae.add_supported_context(Verification, ALL_TRANSFER_SYNTAXES)            # C-ECHO test
    ae.start_server((CFG.get("bind", "0.0.0.0"), int(CFG["local_port"])),
                    evt_handlers=[(evt.EVT_C_STORE, _handle_store)], block=True)


if __name__ == "__main__":
    # Never stop: if the SCP server ever crashes, restart it after a short pause.
    while True:
        try:
            main()
        except KeyboardInterrupt:
            break
        except Exception as e:  # noqa: BLE001
            log.error("server crashed: %s — restarting in 10s", e)
            time.sleep(10)
