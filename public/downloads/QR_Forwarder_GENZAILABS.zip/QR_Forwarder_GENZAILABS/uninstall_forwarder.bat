@echo off
REM ============================================================================
REM  Quick Rad AI Forwarder - UNINSTALLER
REM
REM  Place this file in the SAME FOLDER as qr_forwarder.py, then:
REM      RIGHT-CLICK  ->  Run as administrator
REM
REM  What it does:
REM    1. Stops the QuickRadForwarder scheduled task
REM    2. Kills any leftover pythonw.exe running the forwarder
REM    3. Deletes the scheduled task
REM    4. Removes the Windows Firewall inbound rule for port 11120
REM    5. Backs up qr_forwarder_data + forwarder_config.json to a ZIP
REM    6. WARNS if studies are still queued and un-forwarded
REM    7. Only then, and only if you confirm, removes program files / data
REM
REM  SAFETY: patient studies are NEVER deleted without an explicit typed
REM  confirmation. The default answer to every destructive prompt is NO.
REM ============================================================================
setlocal enabledelayedexpansion

set "TASK=QuickRadForwarder"
set "FWRULE=QR Forwarder DICOM"
set "PORT=11120"
cd /d "%~dp0"
set "QRDIR=%~dp0"
if "%QRDIR:~-1%"=="\" set "QRDIR=%QRDIR:~0,-1%"

echo.
echo ============================================================
echo   Quick Rad AI Forwarder - Uninstaller
echo ============================================================
echo   Folder: %QRDIR%
echo.

REM --- must be elevated -------------------------------------------------------
net session >nul 2>&1
if errorlevel 1 (
  echo [ERROR] This must be run as administrator.
  echo         Close this window, RIGHT-CLICK uninstall.bat, "Run as administrator".
  echo.
  pause & exit /b 1
)

REM --- sanity: are we in the right folder? ------------------------------------
if not exist "%QRDIR%\qr_forwarder.py" if not exist "%QRDIR%\qr_forwarder.exe" (
  echo [WARN] qr_forwarder.py / qr_forwarder.exe not found in this folder.
  echo        The task and firewall rule can still be removed, but no files
  echo        will be deleted from here.
  echo.
)

REM ===========================================================================
echo [1/7] Stopping the scheduled task...
schtasks /end /tn "%TASK%" >nul 2>&1
if errorlevel 1 (
  echo       - task was not running ^(or does not exist^)
) else (
  echo       - stopped
)
timeout /t 3 /nobreak >nul

REM ===========================================================================
echo [2/7] Closing any leftover forwarder process...
set "KILLED=0"
for /f "skip=1 tokens=1 delims= " %%P in ('wmic process where "name='pythonw.exe'" get ProcessId 2^>nul') do (
  if not "%%P"=="" (
    taskkill /PID %%P /T /F >nul 2>&1
    if not errorlevel 1 set "KILLED=1"
  )
)
if "!KILLED!"=="1" (echo       - closed pythonw.exe) else (echo       - none running)

echo       Checking port %PORT% is free...
set "PORTBUSY=0"
for /f "tokens=5" %%A in ('netstat -ano ^| findstr :%PORT% 2^>nul') do set "PORTBUSY=1"
if "!PORTBUSY!"=="1" (
  echo       [WARN] something is STILL listening on port %PORT%.
  echo              Run:  netstat -ano ^| findstr :%PORT%
  echo              then: taskkill /PID ^<pid^> /F
) else (
  echo       - port %PORT% is free
)

REM ===========================================================================
echo [3/7] Deleting the scheduled task...
schtasks /query /tn "%TASK%" >nul 2>&1
if errorlevel 1 (
  echo       - task "%TASK%" not found, nothing to delete
) else (
  schtasks /delete /tn "%TASK%" /f >nul 2>&1
  if errorlevel 1 (echo       [WARN] could not delete task) else (echo       - task deleted)
)

REM ===========================================================================
echo [4/7] Removing the Windows Firewall rule...
netsh advfirewall firewall delete rule name="%FWRULE%" >nul 2>&1
if errorlevel 1 (
  echo       - no rule named "%FWRULE%" ^(may have a different name^)
) else (
  echo       - firewall rule removed
)

REM ===========================================================================
echo [5/7] Backing up data and config...
set "DATADIR=%QRDIR%\qr_forwarder_data"
set "STAMP=%DATE:~-4%%DATE:~3,2%%DATE:~0,2%_%TIME:~0,2%%TIME:~3,2%"
set "STAMP=!STAMP: =0!"
set "BACKUP=%USERPROFILE%\qr_uninstall_backup_!STAMP!.zip"

if exist "%DATADIR%" (
  powershell -NoProfile -Command ^
    "$p=@(); if (Test-Path '%DATADIR%'){$p+='%DATADIR%'}; if (Test-Path '%QRDIR%\forwarder_config.json'){$p+='%QRDIR%\forwarder_config.json'}; if($p.Count -gt 0){Compress-Archive -Path $p -DestinationPath '!BACKUP!' -Force}" >nul 2>&1
  if exist "!BACKUP!" (
    echo       - backup written to:
    echo         !BACKUP!
  ) else (
    echo       [WARN] backup FAILED. Do not delete anything until you have a copy.
    set "BACKUPFAILED=1"
  )
) else (
  echo       - no qr_forwarder_data folder found, nothing to back up
)

REM ===========================================================================
echo [6/7] Checking for studies that have NOT reached the cloud...
set /a QUEUED=0
if exist "%DATADIR%\incoming" (
  for /d %%D in ("%DATADIR%\incoming\*") do set /a QUEUED+=1
)
echo       - un-forwarded studies waiting in \incoming : !QUEUED!
if !QUEUED! GTR 0 (
  echo.
  echo       ****************************************************************
  echo       *  WARNING: !QUEUED! study^(ies^) have NOT been sent to the cloud. *
  echo       *  Deleting the data folder now = PATIENT DATA LOSS.            *
  echo       *  Re-install and let them forward BEFORE removing data.        *
  echo       ****************************************************************
  echo.
  dir /b /ad "%DATADIR%\incoming"
  echo.
)

REM ===========================================================================
echo [7/7] Optional file removal
echo.
echo   The service is now STOPPED and the auto-start task is REMOVED.
echo   That is all most people need. You can stop here.
echo.
echo   Choose what to remove from this folder:
echo     [1] Nothing            - keep all files ^(safe, recommended^)
echo     [2] Program files only - remove .py/.bat/README, KEEP study data
echo     [3] Everything         - remove program files AND all study data
echo.
set "CHOICE="
set /p "CHOICE=Enter 1, 2 or 3 (default 1): "
if not defined CHOICE set "CHOICE=1"

if "!CHOICE!"=="1" goto :done

if "!CHOICE!"=="2" (
  call :removeprogram
  goto :done
)

if "!CHOICE!"=="3" (
  if !QUEUED! GTR 0 (
    echo.
    echo   !QUEUED! un-forwarded study^(ies^) will be PERMANENTLY DELETED.
  )
  if "!BACKUPFAILED!"=="1" (
    echo   The backup FAILED - there is no copy of this data anywhere else.
  )
  echo.
  echo   Type  DELETE  in capitals to confirm, or anything else to cancel.
  set "CONFIRM="
  set /p "CONFIRM=Confirm: "
  if /i not "!CONFIRM!"=="DELETE" (
    echo   Cancelled. Nothing was deleted.
    goto :done
  )
  call :removeprogram
  echo   Removing study data...
  rmdir /s /q "%DATADIR%" 2>nul
  if exist "%DATADIR%" (echo   [WARN] could not fully remove %DATADIR%) else (echo   - study data removed)
  goto :done
)

echo   Unrecognised choice - nothing was deleted.
goto :done

REM ---------------------------------------------------------------------------
:removeprogram
echo   Removing program files...
del /q "%QRDIR%\qr_forwarder.py"       2>nul
del /q "%QRDIR%\qr_forwarder.exe"      2>nul
del /q "%QRDIR%\forwarder_config.json" 2>nul
del /q "%QRDIR%\requirements.txt"      2>nul
del /q "%QRDIR%\run.bat"               2>nul
del /q "%QRDIR%\install_task.bat"      2>nul
del /q "%QRDIR%\README.md"             2>nul
rmdir /s /q "%QRDIR%\__pycache__"      2>nul
echo   - program files removed
echo   ^(this uninstaller and the folder itself remain - delete them by hand^)
exit /b 0

REM ---------------------------------------------------------------------------
:done
echo.
echo ============================================================
echo   Uninstall finished.
echo.
echo   Task removed   : %TASK%
echo   Firewall rule  : %FWRULE%
if exist "!BACKUP!" echo   Backup ZIP     : !BACKUP!
echo.
echo   Verify with:
echo     schtasks /query /tn "%TASK%"          ^(should say: cannot find^)
echo     netstat -ano ^| findstr :%PORT%        ^(should print nothing^)
echo.
echo   To re-install: put the files back in this folder and
echo   right-click install_task.bat -^> Run as administrator.
echo ============================================================
echo.
pause
endlocal
