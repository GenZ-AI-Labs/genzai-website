@echo off
REM ============================================================================
REM  Quick Rad AI Forwarder - install as a hidden auto-start job
REM
REM  Uses Windows Task Scheduler, NOT NSSM. NSSM must log on as a Windows account
REM  and needs that account's password, which is often unavailable on a PC that
REM  is administered remotely. The Task Scheduler method below avoids that.
REM
REM  RIGHT-CLICK this file  ->  Run as administrator
REM ============================================================================
setlocal
cd /d "%~dp0"

set TASK=QuickRadForwarder

REM --- python.exe runs pip; pythonw.exe runs the forwarder with no console window
set PY=
for /f "delims=" %%P in ('where python 2^>nul') do if not defined PY set PY=%%P
set PYW=
for /f "delims=" %%P in ('where pythonw 2^>nul') do if not defined PYW set PYW=%%P

if not defined PY (
  echo [ERROR] python.exe is not on PATH.
  echo         Reinstall Python and tick "Add python.exe to PATH".
  pause & exit /b 1
)
if not defined PYW (
  echo [ERROR] pythonw.exe is not on PATH ^(it sits next to python.exe^).
  pause & exit /b 1
)
echo Using python : %PY%
echo Using pythonw: %PYW%
echo.

echo [1/4] Installing dependencies ^(pynetdicom, pydicom^)...
"%PY%" -m pip install --quiet -r "%~dp0requirements.txt"
if errorlevel 1 (
  echo [ERROR] pip install failed. Check the internet connection on this PC.
  pause & exit /b 1
)

echo [2/4] Clearing any previous copy of the task...
schtasks /delete /tn "%TASK%" /f >nul 2>&1

echo [3/4] Creating the auto-start task...
schtasks /create /tn "%TASK%" /tr "\"%PYW%\" \"%~dp0qr_forwarder.py\"" /sc onlogon /rl highest /f
if errorlevel 1 (
  echo [ERROR] Could not create the task -- did you use "Run as administrator"?
  pause & exit /b 1
)

echo [4/4] Starting it now...
schtasks /run /tn "%TASK%"

echo.
echo ============================================================
schtasks /query /tn "%TASK%" 2>nul
echo ============================================================
echo.
echo Installed. The forwarder runs hidden and starts again at every logon.
echo.
echo   Listening on : port 11120  ^(this PC^)
echo   Sends to     : the cloud host + AE set in forwarder_config.json
echo   Log file     : %~dp0qr_forwarder_data\forwarder.log
echo.
echo   Check    : schtasks /query /tn "%TASK%"
echo   Stop     : schtasks /end   /tn "%TASK%"
echo   Remove   : schtasks /delete /tn "%TASK%" /f
echo.
echo   NOTE: this starts at LOGON, so leave this PC logged in. It survives
echo         reboots only once someone logs back in.
echo.
pause
