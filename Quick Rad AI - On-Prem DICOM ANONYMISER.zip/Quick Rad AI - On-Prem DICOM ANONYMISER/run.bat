@echo off
REM ============================================================================
REM  Quick Rad AI ANONYMISER (TESTING) - manual run in a console.
REM  Shows live logs. Receives studies, anonymises them locally to qr_data\output\.
REM  Press Ctrl+C to stop. For 24/7 operation use install.bat.
REM ============================================================================
cd /d "%~dp0"
python -m pip install -r requirements.txt
python qr_forwarder.py --console
pause
