@echo off
REM ============================================================================
REM  Quick Rad AI ANONYMISER - install as an auto-start job (Windows Task Scheduler)
REM
REM  LOCAL-ONLY. This process receives DICOM studies from the scanner, anonymises
REM  them on this PC, and writes them to an output folder for a technician to upload
REM  manually. It makes NO outbound network connection, so this installer opens ONLY
REM  an INBOUND firewall port (for the scanner) - there is no outbound rule.
REM
REM  Needs Python 3.12 installed with "Add python.exe to PATH".
REM  RIGHT-CLICK this file  ->  Run as administrator
REM ============================================================================
setlocal
cd /d "%~dp0"

set TASK=QuickRadAnonymiser
set PORT=11120

set PY=
for /f "delims=" %%P in ('where python 2^>nul') do if not defined PY set PY=%%P
set PYW=
for /f "delims=" %%P in ('where pythonw 2^>nul') do if not defined PYW set PYW=%%P
if not defined PY (
  echo [ERROR] python.exe is not on PATH. Install Python 3.12, tick "Add to PATH".
  pause & exit /b 1
)
if not defined PYW ( echo [ERROR] pythonw.exe not on PATH. & pause & exit /b 1 )
echo Using: %PY%
echo.

echo [1/4] Installing dependencies ^(pynetdicom, pydicom^)...
"%PY%" -m pip install --quiet -r "%~dp0requirements.txt"
if errorlevel 1 ( echo [ERROR] pip install failed - check internet. & pause & exit /b 1 )

echo [2/4] Opening INBOUND firewall port for the scanner ^(TCP %PORT%^)...
echo       ^(No outbound rule is added - this software never connects out.^)
netsh advfirewall firewall delete rule name="QR Anonymiser DICOM" >nul 2>&1
netsh advfirewall firewall add rule name="QR Anonymiser DICOM" dir=in action=allow protocol=TCP localport=%PORT% >nul

echo [3/4] Creating the auto-start task...
schtasks /delete /tn "%TASK%" /f >nul 2>&1
schtasks /create /tn "%TASK%" /tr "\"%PYW%\" \"%~dp0qr_forwarder.py\"" /sc onlogon /rl highest /f
if errorlevel 1 ( echo [ERROR] Could not create task - use "Run as administrator". & pause & exit /b 1 )

echo [4/4] Starting it now...
schtasks /run /tn "%TASK%"

echo.
echo ============================================================
schtasks /query /tn "%TASK%" 2>nul
echo ============================================================
echo.
echo Installed. Receives on port %PORT%, anonymises locally, writes to:
echo    %~dp0qr_data\output\   ^(a technician uploads these to Quick Rad AI^)
echo Log: %~dp0qr_data\anonymiser.log
echo.
echo   TO REMOVE COMPLETELY, run these two lines:
echo     schtasks /delete /tn "%TASK%" /f
echo     netsh advfirewall firewall delete rule name="QR Anonymiser DICOM"
echo.
echo   NOTE: starts at LOGON. For boot-without-login, replace  /sc onlogon
echo         with  /sc onstart /ru SYSTEM  above.
echo.
pause
