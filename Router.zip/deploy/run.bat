@echo off
REM ============================================================================
REM  Quick Rad AI Forwarder (TESTING) - manual run in a console, for testing only.
REM  Shows a console window with live logs. Press Ctrl+C to stop.
REM  For 24/7 operation, deploy the signed installer (Windows Service) instead.
REM ============================================================================
cd /d "%~dp0"
python -m pip install -r requirements.txt
python qr_forwarder.py --console
pause
