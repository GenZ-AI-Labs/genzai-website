@echo off
REM ============================================================================
REM  Quick Rad AI Forwarder - install as an auto-start job (Windows Task Scheduler)
REM  Simple, source-based. Needs Python 3.12 installed with "Add to PATH".
REM
REM  RIGHT-CLICK this file  ->  Run as administrator
REM ============================================================================
setlocal
cd /d "%~dp0"

set TASK=QuickRadForwarder
set PORT=11120

REM --- python.exe runs pip; pythonw.exe runs the forwarder with no console window
set PY=
for /f "delims=" %%P in ('where python 2^>nul') do if not defined PY set PY=%%P
set PYW=
for /f "delims=" %%P in ('where pythonw 2^>nul') do if not defined PYW set PYW=%%P

if not defined PY (
  echo [ERROR] python.exe is not on PATH.
  echo         Install Python 3.12 and tick "Add python.exe to PATH".
  pause & exit /b 1
)
if not defined PYW (
  echo [ERROR] pythonw.exe is not on PATH ^(it sits next to python.exe^).
  pause & exit /b 1
)
echo Using: %PY%
echo.

echo [1/4] Installing dependencies ^(pynetdicom, pydicom^)...
"%PY%" -m pip install --quiet -r "%~dp0requirements.txt"
if errorlevel 1 (
  echo [ERROR] pip install failed. Check this PC's internet connection.
  pause & exit /b 1
)

echo [2/4] Opening the inbound firewall port for the scanner ^(TCP %PORT%^)...
netsh advfirewall firewall delete rule name="QR Forwarder DICOM" >nul 2>&1
netsh advfirewall firewall add rule name="QR Forwarder DICOM" dir=in action=allow protocol=TCP localport=%PORT% >nul

echo [3/4] Creating the auto-start task...
schtasks /delete /tn "%TASK%" /f >nul 2>&1
schtasks /create /tn "%TASK%" /tr "\"%PYW%\" \"%~dp0qr_forwarder.py\"" /sc onlogon /rl highest /f
if errorlevel 1 (
  echo [ERROR] Could not create the task -- did you use "Run as administrator"?
  pause & exit /b 1
)

echo [4/4] Starting it now...
schtasks /run /tn "%TASK%"

echo.
echo ============================================================
schtasks /query /tn "%TASK%" 2>nul
echo ============================================================
echo.
echo Installed. Runs hidden, starts again at every logon.
echo   Listening on : port %PORT%  ^(this PC^)
echo   Sends to     : quickradai.genzailabs.com:11112 as AE KAUVERY_HOSPITAL
echo   Log file     : %~dp0qr_forwarder_data\forwarder.log
echo.
echo   Check  : schtasks /query /tn "%TASK%"
echo   Stop   : schtasks /end   /tn "%TASK%"
echo   Remove : schtasks /delete /tn "%TASK%" /f
echo.
echo   NOTE: starts at LOGON, so leave this PC logged in. (To start at BOOT with
echo         no login, replace  /sc onlogon  with  /sc onstart /ru SYSTEM  above.)
echo.
pause
