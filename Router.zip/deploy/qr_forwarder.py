"""Quick Rad AI — on-prem DICOM forwarder (store-and-forward gateway).

Runs on a hospital PC that has internet access. The scanner/PACS sends studies to
THIS PC as a local DICOM node (on the hospital LAN); this service receives them
and forwards each study to the Quick Rad AI cloud, stamping the branch's Calling
AE title so the cloud routes it to the correct branch.

Store-and-forward with retry: if the internet or cloud is temporarily down, studies
are kept on disk and retried until they go through — nothing is lost.

Run models
----------
* **Windows Service** (production): frozen to QuickRadForwarder.exe with PyInstaller
  and installed via install_service.bat. Runs as the built-in LocalSystem account —
  NO Windows password required — starts at boot, and is restarted by the Service
  Control Manager on failure. This replaces the old hidden Task Scheduler job.
* **Console** (testing): `python qr_forwarder.py --console` (or run.bat) shows live
  logs; Ctrl+C to stop.

Receive is a FAST PATH: incoming instances are written to disk as raw bytes with no
decode/re-encode, so C-STORE responses return to the scanner immediately. Decoding
happens later, in the background forward loop, off the scanner's path.

Config: forwarder_config.json (next to the exe / this script).
"""
from __future__ import annotations

import io
import os
import sys
import json
import time
import shutil
import logging
import threading

from pynetdicom import (AE, evt, AllStoragePresentationContexts,
                        ALL_TRANSFER_SYNTAXES)
from pynetdicom.sop_class import Verification
import pydicom
from pydicom.filewriter import write_file_meta_info


# Folder the exe/script lives in — works both as a .py and as a PyInstaller .exe.
def base_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


HERE = base_dir()

# Only the two UIDs we need to file the instance — a header-only read (no pixels).
_UID_TAGS = [0x0020000D, 0x00080018]   # StudyInstanceUID, SOPInstanceUID


def load_config() -> dict:
    with open(os.path.join(HERE, "forwarder_config.json"), encoding="utf-8") as f:
        return json.load(f)


class Forwarder:
    """The whole gateway: a receive SCP + a background forward loop, wrapped so it
    can be cleanly started and stopped (needed for a Windows Service)."""

    def __init__(self) -> None:
        self.cfg = load_config()
        self.data = os.path.abspath(
            os.path.join(HERE, self.cfg.get("storage_dir", "qr_forwarder_data")))
        self.incoming = os.path.join(self.data, "incoming")
        self.sent = os.path.join(self.data, "sent")
        for d in (self.incoming, self.sent):
            os.makedirs(d, exist_ok=True)

        self.log = self._setup_logging()
        self._last_seen: dict[str, float] = {}
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._server = None
        self._loop_thread: threading.Thread | None = None

    def _setup_logging(self) -> logging.Logger:
        handlers: list[logging.Handler] = [
            logging.FileHandler(os.path.join(self.data, "forwarder.log"),
                                encoding="utf-8"),
        ]
        # A frozen Windows Service has no console; only add stdout when we have one.
        if sys.stdout is not None:
            handlers.append(logging.StreamHandler(sys.stdout))
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s %(levelname)s %(message)s",
            handlers=handlers,
        )
        return logging.getLogger("qr-forwarder")

    # ── Receive (SCP): the scanner pushes studies here — FAST, no decode ────────
    def _handle_store(self, event):
        """Write the incoming instance to disk as raw bytes (no decode / no
        re-encode) and acknowledge immediately."""
        fm = event.file_meta
        raw = event.request.DataSet.getvalue()      # raw encoded dataset, not decoded

        buf = io.BytesIO()
        buf.write(b"\x00" * 128)
        buf.write(b"DICM")
        write_file_meta_info(buf, fm)
        buf.write(raw)
        blob = buf.getvalue()

        try:
            hdr = pydicom.dcmread(io.BytesIO(blob), stop_before_pixels=True,
                                  specific_tags=_UID_TAGS)
            study_uid = str(getattr(hdr, "StudyInstanceUID", "") or "unknown")
            sop = str(getattr(hdr, "SOPInstanceUID", "") or "")
        except Exception:
            study_uid, sop = "unknown", ""
        if not sop:
            sop = str(getattr(event.request, "AffectedSOPInstanceUID", None)
                      or time.time_ns())

        sdir = os.path.join(self.incoming, study_uid)
        os.makedirs(sdir, exist_ok=True)
        try:
            with open(os.path.join(sdir, sop + ".dcm"), "wb") as f:
                f.write(blob)
        except Exception as e:  # noqa: BLE001
            self.log.error("store write failed for %s: %s", sop, e)
            return 0xA700   # Out of Resources — the scanner resends just this image
        with self._lock:
            self._last_seen[study_uid] = time.time()
        return 0x0000  # Success

    # ── Forward (SCU): push a completed study to the cloud ──────────────────────
    def _forward_study(self, study_uid: str) -> bool:
        sdir = os.path.join(self.incoming, study_uid)
        files = [os.path.join(sdir, f) for f in os.listdir(sdir)
                 if f.lower().endswith(".dcm")]
        if not files:
            return True

        contexts, datasets = set(), []
        for f in files:
            try:
                ds = pydicom.dcmread(f)
                ts = ds.file_meta.TransferSyntaxUID
                contexts.add((ds.SOPClassUID, ts))
                datasets.append(ds)
            except Exception as e:  # noqa: BLE001
                self.log.warning("unreadable file skipped: %s (%s)", f, e)
        if not datasets:
            return True

        ae = AE(ae_title=self.cfg["branch_ae_title"])
        for sop_class, ts in contexts:
            ae.add_requested_context(sop_class, ts)
        try:
            assoc = ae.associate(self.cfg["cloud_host"], int(self.cfg["cloud_port"]),
                                 ae_title=self.cfg.get("cloud_ae_title", "QUICKRAD_AI"))
        except Exception as e:  # noqa: BLE001
            self.log.error("associate to cloud failed: %s", e)
            return False
        if not assoc.is_established:
            self.log.error("cloud rejected the association "
                           "(check AE title registration / firewall)")
            return False

        ok, n = True, 0
        for ds in datasets:
            try:
                st = assoc.send_c_store(ds)
                if not st or st.Status != 0x0000:
                    self.log.error("C-STORE rejected status=0x%04X",
                                   getattr(st, "Status", -1))
                    ok = False
                    break
                n += 1
            except Exception as e:  # noqa: BLE001
                self.log.error("C-STORE send error: %s", e)
                ok = False
                break
        assoc.release()
        if ok:
            self.log.info("forwarded %d image(s) for study %s", n, study_uid)
        return ok

    def _purge_old_sent(self) -> None:
        keep_days = float(self.cfg.get("keep_sent_days", 3))
        cutoff = time.time() - keep_days * 86400
        for name in os.listdir(self.sent):
            p = os.path.join(self.sent, name)
            try:
                if os.path.isdir(p) and os.path.getmtime(p) < cutoff:
                    shutil.rmtree(p, ignore_errors=True)
            except Exception:
                pass

    def _forward_loop(self) -> None:
        quiet = int(self.cfg.get("quiet_seconds", 15))
        retry = int(self.cfg.get("retry_seconds", 30))
        while not self._stop.is_set():
            try:
                now = time.time()
                with self._lock:
                    seen = dict(self._last_seen)
                ready = []
                for study_uid in os.listdir(self.incoming):
                    sdir = os.path.join(self.incoming, study_uid)
                    if not os.path.isdir(sdir):
                        continue
                    last = seen.get(study_uid) or os.path.getmtime(sdir)
                    if now - last > quiet:      # study is complete (quiet) or leftover
                        ready.append(study_uid)
                for study_uid in ready:
                    if self._stop.is_set():
                        break
                    self.log.info("forwarding study %s as '%s' -> %s:%s", study_uid,
                                  self.cfg["branch_ae_title"], self.cfg["cloud_host"],
                                  self.cfg["cloud_port"])
                    if self._forward_study(study_uid):
                        dst = os.path.join(self.sent, study_uid)
                        if os.path.exists(dst):
                            shutil.rmtree(dst, ignore_errors=True)
                        try:
                            os.rename(os.path.join(self.incoming, study_uid), dst)
                        except Exception:
                            pass
                        with self._lock:
                            self._last_seen.pop(study_uid, None)
                    else:
                        self.log.warning(
                            "study %s not forwarded — will retry in %ss",
                            study_uid, retry)
                self._purge_old_sent()
            except Exception as e:  # noqa: BLE001
                self.log.error("forward loop error: %s", e)
            # Interruptible sleep so the service stops promptly.
            self._stop.wait(retry)

    # ── lifecycle ───────────────────────────────────────────────────────────────
    def start(self) -> None:
        self.log.info(
            "Quick Rad AI forwarder | branch='%s' | listen %s:%s (AE %s) | "
            "cloud %s:%s (AE %s)",
            self.cfg["branch_ae_title"], self.cfg.get("bind", "0.0.0.0"),
            self.cfg["local_port"], self.cfg.get("local_ae_title", "QR_GATEWAY"),
            self.cfg["cloud_host"], self.cfg["cloud_port"],
            self.cfg.get("cloud_ae_title", "QUICKRAD_AI"))

        self._loop_thread = threading.Thread(target=self._forward_loop, daemon=True)
        self._loop_thread.start()

        ae = AE(ae_title=self.cfg.get("local_ae_title", "QR_GATEWAY"))
        # Generous negotiation so a big MR series never trips a sender timeout.
        ae.maximum_pdu_size = 0            # 0 = no limit; let the scanner use big PDUs
        ae.acse_timeout = 120
        ae.dimse_timeout = 120
        ae.network_timeout = 600
        for cx in AllStoragePresentationContexts:          # accept every storage class
            ae.add_supported_context(cx.abstract_syntax, ALL_TRANSFER_SYNTAXES)
        ae.add_supported_context(Verification, ALL_TRANSFER_SYNTAXES)   # C-ECHO test
        # Non-blocking: returns a server we can shut down from another thread.
        self._server = ae.start_server(
            (self.cfg.get("bind", "0.0.0.0"), int(self.cfg["local_port"])),
            evt_handlers=[(evt.EVT_C_STORE, self._handle_store)], block=False)

    def stop(self) -> None:
        self.log.info("stopping forwarder ...")
        self._stop.set()
        if self._server is not None:
            try:
                self._server.shutdown()
            except Exception:
                pass
            self._server = None

    def run_console(self) -> None:
        """Blocking run for testing. Ctrl+C to stop."""
        self.start()
        try:
            while not self._stop.is_set():
                time.sleep(1)
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()


# ── Windows Service wrapper (production) ────────────────────────────────────────
# pywin32 is only present/needed on Windows. Guard the import so the file still
# imports and runs in console mode on any platform.
try:
    import win32serviceutil
    import win32service
    import win32event
    import servicemanager
    _HAVE_PYWIN32 = True
except Exception:  # noqa: BLE001
    _HAVE_PYWIN32 = False


if _HAVE_PYWIN32:

    class QuickRadService(win32serviceutil.ServiceFramework):
        _svc_name_ = "QuickRadForwarder"
        _svc_display_name_ = "Quick Rad AI DICOM Forwarder"
        _svc_description_ = ("Store-and-forward DICOM gateway. Receives studies from "
                             "the local scanner and forwards them to the Quick Rad AI "
                             "cloud. (GenZ AI Labs)")

        def __init__(self, args):
            win32serviceutil.ServiceFramework.__init__(self, args)
            self.fwd: Forwarder | None = None
            self._hstop = win32event.CreateEvent(None, 0, 0, None)

        def SvcStop(self):
            self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
            if self.fwd is not None:
                self.fwd.stop()
            win32event.SetEvent(self._hstop)

        def SvcDoRun(self):
            servicemanager.LogMsg(
                servicemanager.EVENTLOG_INFORMATION_TYPE,
                servicemanager.PYS_SERVICE_STARTED,
                (self._svc_name_, ""))
            try:
                self.fwd = Forwarder()
                self.fwd.start()
                win32event.WaitForSingleObject(self._hstop, win32event.INFINITE)
            except Exception as e:  # noqa: BLE001
                servicemanager.LogErrorMsg(f"QuickRadForwarder failed: {e}")
                # Non-zero exit tells the SCM to apply recovery/restart.
                raise


def main() -> None:
    # Explicit console mode, or any non-Windows / no-pywin32 environment (e.g.
    # running the raw .py for testing) → just run in the foreground.
    if "--console" in sys.argv or not _HAVE_PYWIN32:
        Forwarder().run_console()
        return

    # Frozen exe: point the SCM at the exe, not at pythonservice.exe.
    QuickRadService._exe_name_ = sys.executable

    if len(sys.argv) == 1:
        # No args → the SCM started us. Hand control to the dispatcher.
        try:
            servicemanager.Initialize()
            servicemanager.PrepareToHostSingle(QuickRadService)
            servicemanager.StartServiceCtrlDispatcher()
        except win32service.error:
            # Not launched by the SCM (e.g. double-clicked) → run in console.
            Forwarder().run_console()
    else:
        # install / remove / start / stop / --startup auto, etc.
        win32serviceutil.HandleCommandLine(QuickRadService)


if __name__ == "__main__":
    main()
