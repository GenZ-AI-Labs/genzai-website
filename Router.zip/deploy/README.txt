Quick Rad AI - On-Prem DICOM Forwarder (KAUVERY_HOSPITAL)
=========================================================

Install on the hospital PC that has internet access.

1. Install Python 3.12 from https://www.python.org/downloads/
   -> tick "Add python.exe to PATH" during install.

2. Unzip this folder somewhere permanent, e.g. C:\QR_Forwarder

3. (Optional) Test first: double-click run.bat. You should see:
     Quick Rad AI forwarder | branch='KAUVERY_HOSPITAL' | listen ...
   Press Ctrl+C to stop.

4. Install as an auto-start job:
   RIGHT-CLICK install.bat  ->  Run as administrator

5. Point the scanner/PACS at THIS PC:
     Called AE : QR_GATEWAY
     IP / Host : <this PC's LAN IP>   (run: ipconfig)
     Port      : 11120
   Do a DICOM Echo (should succeed), then send one study.

Settings live in forwarder_config.json (branch AE title, ports, cloud endpoint).
Logs: qr_forwarder_data\forwarder.log

Cloud endpoint: quickradai.genzailabs.com : 11112  (AE QUICKRAD_AI)

Manage the job:
  schtasks /query  /tn "QuickRadForwarder"   :: status
  schtasks /end    /tn "QuickRadForwarder"   :: stop
  schtasks /delete /tn "QuickRadForwarder" /f:: remove
